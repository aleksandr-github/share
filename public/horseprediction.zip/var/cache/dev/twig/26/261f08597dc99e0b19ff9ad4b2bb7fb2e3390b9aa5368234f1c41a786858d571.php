<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* race.html.twig */
class __TwigTemplate_18cd9e9f2868d390fb3a54d55c1b8d50c9aa21bbe76bf5755e9ac5cf9fa3a889 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "race.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "race.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "race.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->loadTemplate("partial/nav.html.twig", "race.html.twig", 4)->display($context);
        // line 5
        echo "
    <div class=\"container-fluid\">
        <h1>Horses Rating - Distance ";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["raceDetails"]) || array_key_exists("raceDetails", $context) ? $context["raceDetails"] : (function () { throw new RuntimeError('Variable "raceDetails" does not exist.', 7, $this->source); })()), "round_distance", [], "any", false, false, false, 7), "html", null, true);
        echo " </h1>
        <table id=\"employee_grid\" class=\"display\" width=\"100%\" cellspacing=\"0\">
            <thead>
                <tr>
                    ";
        // line 11
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 11, $this->source); })()), "request", [], "any", false, false, false, 11), "get", [0 => "avg"], "method", false, false, false, 11), 1))) {
            // line 12
            echo "                        <th>No</th>
                        <th>Name</th>
                        <th>Form</th>
                        <th>Odds</th>
                        <th>Weight</th>
                        <th>Current Weight</th>
                        <th>Rating</th>
                        <th>Profit & Loss</th>
                        <th>AVG Rank</th>
                        <th>Profit</th>
                    ";
        } else {
            // line 23
            echo "                        <th>No</th>
                        <th>Name</th>
                        <th>Form</th>
                        <th>Odds</th>
                        <th>Distance</th>
                        <th>Sectional</th>
                        <th>Minimum Time</th>
                        <th>Race Pos</th>
                        <th>Orig Weight</th>
                        <th>Current Weight</th>
                        <th>Handicap</th>
                        <th>Rating</th>
                        <th>Rank</th>
                    ";
        }
        // line 37
        echo "                </tr>
            </thead>
                <tbody>
                ";
        // line 40
        if ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 40, $this->source); })()), "request", [], "any", false, false, false, 40), "get", [0 => "avg"], "method", false, false, false, 40), 1))) {
            // line 41
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["resultsCombinedArray"]) || array_key_exists("resultsCombinedArray", $context) ? $context["resultsCombinedArray"] : (function () { throw new RuntimeError('Variable "resultsCombinedArray" does not exist.', 41, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
                // line 42
                echo "                        <tr>
                            <td>";
                // line 43
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseNum", [], "any", false, false, false, 43), "html", null, true);
                echo "</td>
                            <td>";
                // line 44
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseName", [], "any", false, false, false, 44), "html", null, true);
                echo "</td>
                            <td>";
                // line 45
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseLatestResults", [], "any", false, false, false, 45), "html", null, true);
                echo "</td>
                            <td>";
                // line 46
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseFxOdds", [], "any", false, false, false, 46), "html", null, true);
                echo "</td>
                            <td>";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceDistance", [], "any", false, false, false, 47), "html", null, true);
                echo "</td>
                            <td>";
                // line 48
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceSectional", [], "any", false, false, false, 48), "html", null, true);
                echo "</td>
                            <td>";
                // line 49
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceTime", [], "any", false, false, false, 49), "html", null, true);
                echo "</td>
                            <td>";
                // line 50
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceHorsePosition", [], "any", false, false, false, 50), "html", null, true);
                echo "</td>
                            <td>";
                // line 51
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceWeight", [], "any", false, false, false, 51), "html", null, true);
                echo "</td>
                            <td>";
                // line 52
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseWeight", [], "any", false, false, false, 52), "html", null, true);
                echo "</td>
                            <td>";
                // line 53
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "handicap", [], "any", false, false, false, 53), "html", null, true);
                echo "</td>
                            <td>";
                // line 54
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "rating", [], "any", false, false, false, 54), "html", null, true);
                echo "</td>
                            <td>";
                // line 55
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "rank", [], "any", false, false, false, 55), "html", null, true);
                echo "</td>
                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            echo "                ";
        } else {
            // line 59
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["resultsCombinedArray"]) || array_key_exists("resultsCombinedArray", $context) ? $context["resultsCombinedArray"] : (function () { throw new RuntimeError('Variable "resultsCombinedArray" does not exist.', 59, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
                // line 60
                echo "                        <tr>
                            <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseNum", [], "any", false, false, false, 61), "html", null, true);
                echo "</td>
                            <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseName", [], "any", false, false, false, 62), "html", null, true);
                echo "</td>
                            <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseLatestResults", [], "any", false, false, false, 63), "html", null, true);
                echo "</td>
                            <td>";
                // line 64
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseFxOdds", [], "any", false, false, false, 64), "html", null, true);
                echo "</td>
                            <td>";
                // line 65
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "raceWeight", [], "any", false, false, false, 65), "html", null, true);
                echo "</td>
                            <td>";
                // line 66
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "horseWeight", [], "any", false, false, false, 66), "html", null, true);
                echo "</td>
                            <td>";
                // line 67
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "rating", [], "any", false, false, false, 67), "html", null, true);
                echo "</td>
                            <td>";
                // line 68
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "profitLoss", [], "any", false, false, false, 68), "html", null, true);
                echo "</td>
                            <td>";
                // line 69
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "rank", [], "any", false, false, false, 69), "html", null, true);
                echo "</td>
                            <td>";
                // line 70
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["result"], "profit", [], "any", false, false, false, 70), "html", null, true);
                echo "</td>
                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 73
            echo "                ";
        }
        // line 74
        echo "                </tbody>
            <tfoot>
                <tr>
                ";
        // line 77
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 77, $this->source); })()), "request", [], "any", false, false, false, 77), "get", [0 => "avg"], "method", false, false, false, 77), 1))) {
            // line 78
            echo "                    <th>No</th>
                    <th>Name</th>
                    <th>Form</th>
                    <th>Odds</th>
                    <th>Weight</th>
                    <th>Current Weight</th>
                    <th>Rating</th>
                    <th>Profit & Loss</th>
                    <th>AVG Rank</th>
                    <th>Profit</th>
                ";
        } else {
            // line 89
            echo "                    <th>No</th>
                    <th>Name</th>
                    <th>Form</th>
                    <th>Odds</th>
                    <th>Distance</th>
                    <th>Sectional</th>
                    <th>Minimum Time</th>
                    <th>Race Pos</th>
                    <th>Orig Weight</th>
                    <th>Current Weight</th>
                    <th>Handicap</th>
                    <th>Rating</th>
                    <th>Rank</th>
                ";
        }
        // line 103
        echo "                </tr>
            </tfoot>
        </table>
    </div>
    <hr/>
    <div class=\"container-fluid\">
        <div class=\"\">
            <h1>Race Results for ";
        // line 110
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["raceDetails"]) || array_key_exists("raceDetails", $context) ? $context["raceDetails"] : (function () { throw new RuntimeError('Variable "raceDetails" does not exist.', 110, $this->source); })()), "race_title", [], "any", false, false, false, 110), "html", null, true);
        echo "</h1>
            <div class=\"table\">
                <table id=\"employee_grid1\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                    <thead>
                    <tr>
                        <th>Position</th>
                        <th>Horse Name</th>
                        <th>Distance</th>
                        <th>Event</th>
                        <th>Race Name</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 123
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resultsForRace"]) || array_key_exists("resultsForRace", $context) ? $context["resultsForRace"] : (function () { throw new RuntimeError('Variable "resultsForRace" does not exist.', 123, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["raceResult"]) {
            // line 124
            echo "                        <tr>
                            <td>";
            // line 125
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["raceResult"], "raceResultPosition", [], "any", false, false, false, 125), "html", null, true);
            echo "</td>
                            <td>";
            // line 126
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["raceResult"], "horseName", [], "any", false, false, false, 126), "html", null, true);
            echo "</td>
                            <td>";
            // line 127
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["raceResult"], "roundDistance", [], "any", false, false, false, 127), "html", null, true);
            echo "</td>
                            <td>";
            // line 128
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["raceResult"], "meetingName", [], "any", false, false, false, 128), "html", null, true);
            echo "</td>
                            <td><a href=''";
            // line 129
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_details", ["meeting" => (isset($context["meetingId"]) || array_key_exists("meetingId", $context) ? $context["meetingId"] : (function () { throw new RuntimeError('Variable "meetingId" does not exist.', 129, $this->source); })()), "race" => (isset($context["raceId"]) || array_key_exists("raceId", $context) ? $context["raceId"] : (function () { throw new RuntimeError('Variable "raceId" does not exist.', 129, $this->source); })())]), "html", null, true);
            echo "'>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["raceResult"], "raceName", [], "any", false, false, false, 129), "html", null, true);
            echo "</a></td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['raceResult'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 132
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 139
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 140
        echo "    <script type=\"text/javascript\">
        \$.fn.dataTable.ext.search.push(
            function (settings, data, dataIndex) {
                var min = parseInt(\$('#min').val(), 10);
                var max = parseInt(\$('#max').val(), 10);
                var age = parseFloat(data[6]) || 0; // use data for the age column

                if ((isNaN(min) && isNaN(max)) ||
                    (isNaN(min) && age <= max) ||
                    (min <= age && isNaN(max)) ||
                    (min <= age && age <= max)) {
                    return true;
                }
                return false;
            }
        );
        \$(document).ready(function () {
            \$('#employee_grid').DataTable({
                \"pageLength\": 25,
                \"order\": [[7, \"desc\"]]
            });
            \$('#employee_grid1').DataTable({
                \"responsive\": true,
            });
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "race.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  365 => 140,  355 => 139,  340 => 132,  329 => 129,  325 => 128,  321 => 127,  317 => 126,  313 => 125,  310 => 124,  306 => 123,  290 => 110,  281 => 103,  265 => 89,  252 => 78,  250 => 77,  245 => 74,  242 => 73,  233 => 70,  229 => 69,  225 => 68,  221 => 67,  217 => 66,  213 => 65,  209 => 64,  205 => 63,  201 => 62,  197 => 61,  194 => 60,  189 => 59,  186 => 58,  177 => 55,  173 => 54,  169 => 53,  165 => 52,  161 => 51,  157 => 50,  153 => 49,  149 => 48,  145 => 47,  141 => 46,  137 => 45,  133 => 44,  129 => 43,  126 => 42,  121 => 41,  119 => 40,  114 => 37,  98 => 23,  85 => 12,  83 => 11,  76 => 7,  72 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {% include 'partial/nav.html.twig' %}

    <div class=\"container-fluid\">
        <h1>Horses Rating - Distance {{ raceDetails.round_distance}} </h1>
        <table id=\"employee_grid\" class=\"display\" width=\"100%\" cellspacing=\"0\">
            <thead>
                <tr>
                    {% if app.request.get('avg') == 1 %}
                        <th>No</th>
                        <th>Name</th>
                        <th>Form</th>
                        <th>Odds</th>
                        <th>Weight</th>
                        <th>Current Weight</th>
                        <th>Rating</th>
                        <th>Profit & Loss</th>
                        <th>AVG Rank</th>
                        <th>Profit</th>
                    {% else %}
                        <th>No</th>
                        <th>Name</th>
                        <th>Form</th>
                        <th>Odds</th>
                        <th>Distance</th>
                        <th>Sectional</th>
                        <th>Minimum Time</th>
                        <th>Race Pos</th>
                        <th>Orig Weight</th>
                        <th>Current Weight</th>
                        <th>Handicap</th>
                        <th>Rating</th>
                        <th>Rank</th>
                    {% endif %}
                </tr>
            </thead>
                <tbody>
                {% if app.request.get('avg') != 1 %}
                    {% for result in resultsCombinedArray %}
                        <tr>
                            <td>{{ result.horseNum }}</td>
                            <td>{{ result.horseName }}</td>
                            <td>{{ result.horseLatestResults }}</td>
                            <td>{{ result.horseFxOdds }}</td>
                            <td>{{ result.raceDistance }}</td>
                            <td>{{ result.raceSectional }}</td>
                            <td>{{ result.raceTime }}</td>
                            <td>{{ result.raceHorsePosition }}</td>
                            <td>{{ result.raceWeight }}</td>
                            <td>{{ result.horseWeight }}</td>
                            <td>{{ result.handicap }}</td>
                            <td>{{ result.rating }}</td>
                            <td>{{ result.rank }}</td>
                        </tr>
                    {% endfor %}
                {% else %}
                    {% for result in resultsCombinedArray %}
                        <tr>
                            <td>{{ result.horseNum }}</td>
                            <td>{{ result.horseName }}</td>
                            <td>{{ result.horseLatestResults }}</td>
                            <td>{{ result.horseFxOdds }}</td>
                            <td>{{ result.raceWeight }}</td>
                            <td>{{ result.horseWeight }}</td>
                            <td>{{ result.rating }}</td>
                            <td>{{ result.profitLoss }}</td>
                            <td>{{ result.rank }}</td>
                            <td>{{ result.profit }}</td>
                        </tr>
                    {% endfor %}
                {% endif %}
                </tbody>
            <tfoot>
                <tr>
                {% if app.request.get('avg') == 1 %}
                    <th>No</th>
                    <th>Name</th>
                    <th>Form</th>
                    <th>Odds</th>
                    <th>Weight</th>
                    <th>Current Weight</th>
                    <th>Rating</th>
                    <th>Profit & Loss</th>
                    <th>AVG Rank</th>
                    <th>Profit</th>
                {% else %}
                    <th>No</th>
                    <th>Name</th>
                    <th>Form</th>
                    <th>Odds</th>
                    <th>Distance</th>
                    <th>Sectional</th>
                    <th>Minimum Time</th>
                    <th>Race Pos</th>
                    <th>Orig Weight</th>
                    <th>Current Weight</th>
                    <th>Handicap</th>
                    <th>Rating</th>
                    <th>Rank</th>
                {% endif %}
                </tr>
            </tfoot>
        </table>
    </div>
    <hr/>
    <div class=\"container-fluid\">
        <div class=\"\">
            <h1>Race Results for {{ raceDetails.race_title }}</h1>
            <div class=\"table\">
                <table id=\"employee_grid1\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                    <thead>
                    <tr>
                        <th>Position</th>
                        <th>Horse Name</th>
                        <th>Distance</th>
                        <th>Event</th>
                        <th>Race Name</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% for raceResult in resultsForRace %}
                        <tr>
                            <td>{{ raceResult.raceResultPosition }}</td>
                            <td>{{ raceResult.horseName }}</td>
                            <td>{{ raceResult.roundDistance }}</td>
                            <td>{{ raceResult.meetingName }}</td>
                            <td><a href=''{{ path('races_details', {\"meeting\": meetingId, \"race\": raceId}) }}'>{{ raceResult.raceName }}</a></td>
                        </tr>
                    {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\">
        \$.fn.dataTable.ext.search.push(
            function (settings, data, dataIndex) {
                var min = parseInt(\$('#min').val(), 10);
                var max = parseInt(\$('#max').val(), 10);
                var age = parseFloat(data[6]) || 0; // use data for the age column

                if ((isNaN(min) && isNaN(max)) ||
                    (isNaN(min) && age <= max) ||
                    (min <= age && isNaN(max)) ||
                    (min <= age && age <= max)) {
                    return true;
                }
                return false;
            }
        );
        \$(document).ready(function () {
            \$('#employee_grid').DataTable({
                \"pageLength\": 25,
                \"order\": [[7, \"desc\"]]
            });
            \$('#employee_grid1').DataTable({
                \"responsive\": true,
            });
        });
    </script>
{% endblock %}", "race.html.twig", "/var/www/horse/public_html/templates/race.html.twig");
    }
}
