<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home.html.twig */
class __TwigTemplate_69a1b61f6ed093b9349ae7495d83ddc1b991084716a3c0929579a106109fa7d8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->loadTemplate("partial/nav.html.twig", "home.html.twig", 4)->display($context);
        // line 5
        echo "
    <div class=\"container-fluid\" style=\"margin-top: 30px\">
        <div class=\"row\">
            <form action=\"";
        // line 8
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index");
        echo "\" id=\"selectionForm\">
                <div class=\"form-group\">
                    <select id=\"mode\" class=\"form-control\">
                      <option value=\"\"> --- CHOOSE DISPLAY OPTION ---</option>
                      <option value=\"2\"> Show data for 2 best results</option>
                      <option value=\"3\"> Show data for 3 best results</option>
                    </select>
                </div>
            </form>
            ";
        // line 17
        if ( !(null === (isset($context["requestMode"]) || array_key_exists("requestMode", $context) ? $context["requestMode"] : (function () { throw new RuntimeError('Variable "requestMode" does not exist.', 17, $this->source); })()))) {
            // line 18
            echo "                ";
            if ((0 === twig_compare((isset($context["requestMode"]) || array_key_exists("requestMode", $context) ? $context["requestMode"] : (function () { throw new RuntimeError('Variable "requestMode" does not exist.', 18, $this->source); })()), 2))) {
                // line 19
                echo "                    <h3>Showing best 2 results</h3>
                ";
            } else {
                // line 21
                echo "                    <h3>Showing best 3 results</h3>
                ";
            }
            // line 23
            echo "            ";
        } else {
            // line 24
            echo "                <h3>Showing best 2 results</h3>
            ";
        }
        // line 26
        echo "        </div>
    </div>
    <div class=\"container-fluid\">
        <div class=\"row\">
            <h2>Profit and Loss for every Race based on Average Rank Field</h2><br/>
            <table class=\"table table-striped table-condensed dataTables\" id=\"indexAVGGrid\">
                <thead>
                    <tr>
                        <th>Race ID</th>
                        <th>Horse</th>
                        <th>Revenue</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["realResultsAVGArray"]) || array_key_exists("realResultsAVGArray", $context) ? $context["realResultsAVGArray"] : (function () { throw new RuntimeError('Variable "realResultsAVGArray" does not exist.', 41, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["realResultAVG"]) {
            // line 42
            echo "                        <tr>
                            <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResultAVG"], "raceId", [], "any", false, false, false, 43), "html", null, true);
            echo "</td>
                            <td>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResultAVG"], "horse", [], "any", false, false, false, 44), "html", null, true);
            echo "</td>
                            <td>\$ ";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResultAVG"], "revenue", [], "any", false, false, false, 45), "html", null, true);
            echo "</td>
                            <td>\$ ";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResultAVG"], "total", [], "any", false, false, false, 46), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['realResultAVG'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                </tbody>
            </table>
            <br/>
            <div class=\"well well-sm\">
                Average Rank Total Profit: \$ ";
        // line 53
        echo twig_escape_filter($this->env, (isset($context["totalProfitAVR"]) || array_key_exists("totalProfitAVR", $context) ? $context["totalProfitAVR"] : (function () { throw new RuntimeError('Variable "totalProfitAVR" does not exist.', 53, $this->source); })()), "html", null, true);
        echo "<br/>
                Avg Rank Current Winnings: \$ ";
        // line 54
        echo twig_escape_filter($this->env, (isset($context["totalLossAVR"]) || array_key_exists("totalLossAVR", $context) ? $context["totalLossAVR"] : (function () { throw new RuntimeError('Variable "totalLossAVR" does not exist.', 54, $this->source); })()), "html", null, true);
        echo "<br/>
                Avg Rank Current Losses: \$ ";
        // line 55
        echo twig_escape_filter($this->env, ((isset($context["totalLossAVR"]) || array_key_exists("totalLossAVR", $context) ? $context["totalLossAVR"] : (function () { throw new RuntimeError('Variable "totalLossAVR" does not exist.', 55, $this->source); })()) - (isset($context["totalProfitAVR"]) || array_key_exists("totalProfitAVR", $context) ? $context["totalProfitAVR"] : (function () { throw new RuntimeError('Variable "totalProfitAVR" does not exist.', 55, $this->source); })())), "html", null, true);
        echo "<br/>
            </div>
        </div>
    </div>
        <br/>
        <hr/>
        <br/>
    <div class=\"container-fluid\">
        <div class=\"row\">
            <h2>Profit and Loss for every Race based on Rating Field</h2><br/>
            <table class=\"table table-striped table-condensed dataTables\" id=\"indexGrid\">
                <thead>
                    <tr>
                        <th>Race ID</th>
                        <th>Horse</th>
                        <th>Revenue</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ";
        // line 75
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["realResultsArray"]) || array_key_exists("realResultsArray", $context) ? $context["realResultsArray"] : (function () { throw new RuntimeError('Variable "realResultsArray" does not exist.', 75, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["realResult"]) {
            // line 76
            echo "                    <tr>
                        <td>";
            // line 77
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResult"], "raceId", [], "any", false, false, false, 77), "html", null, true);
            echo "</td>
                        <td>";
            // line 78
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResult"], "horse", [], "any", false, false, false, 78), "html", null, true);
            echo "</td>
                        <td>\$ ";
            // line 79
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResult"], "revenue", [], "any", false, false, false, 79), "html", null, true);
            echo "</td>
                        <td>\$ ";
            // line 80
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["realResult"], "total", [], "any", false, false, false, 80), "html", null, true);
            echo "</td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['realResult'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "                </tbody>
            </table>
        <br/>
        <div class=\"well well-sm\">
            AVG Rank With Sectional Total Profit: \$";
        // line 87
        echo twig_escape_filter($this->env, (isset($context["totalProfit"]) || array_key_exists("totalProfit", $context) ? $context["totalProfit"] : (function () { throw new RuntimeError('Variable "totalProfit" does not exist.', 87, $this->source); })()), "html", null, true);
        echo "<br/>
            Avg Rank Current Winnings: \$";
        // line 88
        echo twig_escape_filter($this->env, (isset($context["totalLoss"]) || array_key_exists("totalLoss", $context) ? $context["totalLoss"] : (function () { throw new RuntimeError('Variable "totalLoss" does not exist.', 88, $this->source); })()), "html", null, true);
        echo "<br/>
            Avg Rank Current Losses: \$";
        // line 89
        echo twig_escape_filter($this->env, ((isset($context["totalLoss"]) || array_key_exists("totalLoss", $context) ? $context["totalLoss"] : (function () { throw new RuntimeError('Variable "totalLoss" does not exist.', 89, $this->source); })()) - (isset($context["totalProfit"]) || array_key_exists("totalProfit", $context) ? $context["totalProfit"] : (function () { throw new RuntimeError('Variable "totalProfit" does not exist.', 89, $this->source); })())), "html", null, true);
        echo "<br/>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 94
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 95
        echo "<script>
    \$(document).ready(function () {
        \$('.dataTables').DataTable({
            \"responsive\": true,
        });
        \$('#mode').on('change', function() {
            var url = new URL(window.location.href);
            url.searchParams.set('mode', \$(this).find(\":selected\").val());
            window.location.href = url.href;
        });
    });
</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 95,  247 => 94,  233 => 89,  229 => 88,  225 => 87,  219 => 83,  210 => 80,  206 => 79,  202 => 78,  198 => 77,  195 => 76,  191 => 75,  168 => 55,  164 => 54,  160 => 53,  154 => 49,  145 => 46,  141 => 45,  137 => 44,  133 => 43,  130 => 42,  126 => 41,  109 => 26,  105 => 24,  102 => 23,  98 => 21,  94 => 19,  91 => 18,  89 => 17,  77 => 8,  72 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block body %}
    {% include 'partial/nav.html.twig'%}

    <div class=\"container-fluid\" style=\"margin-top: 30px\">
        <div class=\"row\">
            <form action=\"{{ path('index') }}\" id=\"selectionForm\">
                <div class=\"form-group\">
                    <select id=\"mode\" class=\"form-control\">
                      <option value=\"\"> --- CHOOSE DISPLAY OPTION ---</option>
                      <option value=\"2\"> Show data for 2 best results</option>
                      <option value=\"3\"> Show data for 3 best results</option>
                    </select>
                </div>
            </form>
            {% if requestMode is not null %}
                {% if requestMode == 2 %}
                    <h3>Showing best 2 results</h3>
                {% else %}
                    <h3>Showing best 3 results</h3>
                {% endif %}
            {% else %}
                <h3>Showing best 2 results</h3>
            {% endif %}
        </div>
    </div>
    <div class=\"container-fluid\">
        <div class=\"row\">
            <h2>Profit and Loss for every Race based on Average Rank Field</h2><br/>
            <table class=\"table table-striped table-condensed dataTables\" id=\"indexAVGGrid\">
                <thead>
                    <tr>
                        <th>Race ID</th>
                        <th>Horse</th>
                        <th>Revenue</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {% for realResultAVG in realResultsAVGArray %}
                        <tr>
                            <td>{{ realResultAVG.raceId }}</td>
                            <td>{{ realResultAVG.horse }}</td>
                            <td>\$ {{ realResultAVG.revenue }}</td>
                            <td>\$ {{ realResultAVG.total }}</td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
            <br/>
            <div class=\"well well-sm\">
                Average Rank Total Profit: \$ {{ totalProfitAVR }}<br/>
                Avg Rank Current Winnings: \$ {{ totalLossAVR }}<br/>
                Avg Rank Current Losses: \$ {{ totalLossAVR - totalProfitAVR }}<br/>
            </div>
        </div>
    </div>
        <br/>
        <hr/>
        <br/>
    <div class=\"container-fluid\">
        <div class=\"row\">
            <h2>Profit and Loss for every Race based on Rating Field</h2><br/>
            <table class=\"table table-striped table-condensed dataTables\" id=\"indexGrid\">
                <thead>
                    <tr>
                        <th>Race ID</th>
                        <th>Horse</th>
                        <th>Revenue</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {% for realResult in realResultsArray %}
                    <tr>
                        <td>{{ realResult.raceId }}</td>
                        <td>{{ realResult.horse }}</td>
                        <td>\$ {{ realResult.revenue }}</td>
                        <td>\$ {{ realResult.total }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        <br/>
        <div class=\"well well-sm\">
            AVG Rank With Sectional Total Profit: \${{ totalProfit }}<br/>
            Avg Rank Current Winnings: \${{ totalLoss }}<br/>
            Avg Rank Current Losses: \${{ totalLoss - totalProfit }}<br/>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
<script>
    \$(document).ready(function () {
        \$('.dataTables').DataTable({
            \"responsive\": true,
        });
        \$('#mode').on('change', function() {
            var url = new URL(window.location.href);
            url.searchParams.set('mode', \$(this).find(\":selected\").val());
            window.location.href = url.href;
        });
    });
</script>
{% endblock %}", "home.html.twig", "/var/www/horse/public_html/templates/home.html.twig");
    }
}
