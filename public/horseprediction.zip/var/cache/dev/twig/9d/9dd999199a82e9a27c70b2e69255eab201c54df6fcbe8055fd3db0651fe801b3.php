<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* parser/scrape.html.twig */
class __TwigTemplate_c93056164407793bce39b93326dacfee7a149b2bf73460dd58ba1ea653bea4dc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "parser/scrape.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "parser/scrape.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "parser/scrape.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->loadTemplate("partial/nav_parser.html.twig", "parser/scrape.html.twig", 4)->display($context);
        // line 5
        echo "
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">
                <h1>Scrapping for `data`, `meetings`, `races`, `horses` tables</h1>

                <form method=\"post\" id=\"scrapper-form\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label for=\"start_date\">Select start date</label>
                                <input type=\"text\" name=\"start_date\" class=\"form-control datepicker\" id=\"start_date\"
                                       placeholder=\"Select start date\" required>
                            </div>
                        </div>
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label for=\"end_date\">Select end date</label>
                                <input type=\"text\" name=\"end_date\" class=\"form-control datepicker\" id=\"end_date\"
                                       placeholder=\"Select rnd date\" required>
                            </div>
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-primary\" id=\"scrape\" disabled>Scrape</button>
                </form>

                <div class=\"alert alert-danger\" role=\"alert\" id=\"scraper-warning\" style=\"margin-top: 20px\">
                    <p>
                        Due to pthreads developer's controversial decision <a href=\"https://serverfault.com/questions/748001/the-apache2handler-sapi-is-not-supported-by-pthreads\" alt=\"source\">(source)</a>,
                        which results in complete abandoning pthreads support for Apache2handler SAPI,
                        scraper in current version cannot be launched from UI/UX.
                    </p>
                    <p>
                        Please run scraper from command line:
                    </p>
                    <p>
                        <code>
                            \$ cd __PROJECT_DIR__ && php bin/console run:scraper {startDate} {?endDate}
                        </code>
                    </p>
                    <p>Example:</p>
                    <p>
                        <code>
                            \$ cd . && php bin\\console run:scraper 2021-03-03
                        </code>
                    </p>
                </div>

                ";
        // line 56
        echo "
                <div class=\"row\"
                     style=\"margin-top: 20px; background-color: #2b2b2b; color: #999999; font-family: 'Lucida Console', sans-serif; height: 500px; width: auto; font-size: 11px;\">
                    <div class=\"results\"></div>
                    <div class=\"lds-dual-ring\"></div>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 67
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 68
        echo "    <script>
        \$(function () {
            \$(document).ready(function(){
                \$(\"#scrape\").on(\"click\", function(e){
                    e.preventDefault();
                    \$.ajax({
                        type: 'POST',
                        url: \"";
        // line 75
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("parser_scrape_data");
        echo "\",
                        data: \$('#scrapper-form').serialize(),
                        dataType: 'json',
                        success: function (data) {
                            console.log(\"SUCCESS!\");
                        },
                        complete: function (data) {
                            console.log(\"COMPLETE\");
                        },
                        timeout: function (data) {
                            console.log(\"TIMEOUT\");
                        }
                    });
                });
            });

            \$(\".datepicker\").datepicker({
                maxDate: '0',
                dateFormat: 'yy-mm-dd',
                onSelect: function (dateText) { // this.value
                    if ('start_date' == \$(this).attr('id')) {
                        \$(\"#end_date\").datepicker(\"option\", \"minDate\", dateText);
                    }
                    if ('end_date' == \$(this).attr('id')) {
                        \$(\"#start_date\").datepicker(\"option\", \"maxDate\", dateText);
                    }
                }
            }).datepicker(\"setDate\", new Date());
            var lastData;
            var counter = 0;
            var interval = 1000;  // 1000 = 1 second, 3000 = 3 seconds
            function doAjax() {
                \$.ajax({
                    type: 'POST',
                    url: \"";
        // line 109
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("log_main");
        echo "\",
                    data: \$(this).serialize(),
                    dataType: 'json',
                    success: function (data) {
                        if (lastData === data) {
                            counter++;
                            if (counter > 4) {
                                \$('.lds-dual-ring').hide();
                                \$('#scrape').prop('disabled', false);
                                \$('#scraper-running').text(\"Scrapper ready to run.\");
                            }
                        } else {
                            if (lastData != null) {
                                \$('.lds-dual-ring').show();
                                \$('#scrape').prop('disabled', true);
                                \$('#scraper-running').text(\"Scrapper is running.\");
                                counter = 0;
                            }
                        }
                        \$('.results').text(\"\").append(data);// first set the value
                        lastData = data;
                    },
                    complete: function (data) {
                        // Schedule the next
                        setTimeout(doAjax, interval);
                    }
                });
            }

            setTimeout(doAjax, interval);
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "parser/scrape.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  197 => 109,  160 => 75,  151 => 68,  141 => 67,  122 => 56,  72 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {% include 'partial/nav_parser.html.twig' %}

    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">
                <h1>Scrapping for `data`, `meetings`, `races`, `horses` tables</h1>

                <form method=\"post\" id=\"scrapper-form\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label for=\"start_date\">Select start date</label>
                                <input type=\"text\" name=\"start_date\" class=\"form-control datepicker\" id=\"start_date\"
                                       placeholder=\"Select start date\" required>
                            </div>
                        </div>
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label for=\"end_date\">Select end date</label>
                                <input type=\"text\" name=\"end_date\" class=\"form-control datepicker\" id=\"end_date\"
                                       placeholder=\"Select rnd date\" required>
                            </div>
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-primary\" id=\"scrape\" disabled>Scrape</button>
                </form>

                <div class=\"alert alert-danger\" role=\"alert\" id=\"scraper-warning\" style=\"margin-top: 20px\">
                    <p>
                        Due to pthreads developer's controversial decision <a href=\"https://serverfault.com/questions/748001/the-apache2handler-sapi-is-not-supported-by-pthreads\" alt=\"source\">(source)</a>,
                        which results in complete abandoning pthreads support for Apache2handler SAPI,
                        scraper in current version cannot be launched from UI/UX.
                    </p>
                    <p>
                        Please run scraper from command line:
                    </p>
                    <p>
                        <code>
                            \$ cd __PROJECT_DIR__ && php bin/console run:scraper {startDate} {?endDate}
                        </code>
                    </p>
                    <p>Example:</p>
                    <p>
                        <code>
                            \$ cd . && php bin\\console run:scraper 2021-03-03
                        </code>
                    </p>
                </div>

                {#<div class=\"alert alert-info\" role=\"alert\" id=\"scraper-running\">
                    Scraper initializing.
                </div>#}

                <div class=\"row\"
                     style=\"margin-top: 20px; background-color: #2b2b2b; color: #999999; font-family: 'Lucida Console', sans-serif; height: 500px; width: auto; font-size: 11px;\">
                    <div class=\"results\"></div>
                    <div class=\"lds-dual-ring\"></div>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script>
        \$(function () {
            \$(document).ready(function(){
                \$(\"#scrape\").on(\"click\", function(e){
                    e.preventDefault();
                    \$.ajax({
                        type: 'POST',
                        url: \"{{ path('parser_scrape_data') }}\",
                        data: \$('#scrapper-form').serialize(),
                        dataType: 'json',
                        success: function (data) {
                            console.log(\"SUCCESS!\");
                        },
                        complete: function (data) {
                            console.log(\"COMPLETE\");
                        },
                        timeout: function (data) {
                            console.log(\"TIMEOUT\");
                        }
                    });
                });
            });

            \$(\".datepicker\").datepicker({
                maxDate: '0',
                dateFormat: 'yy-mm-dd',
                onSelect: function (dateText) { // this.value
                    if ('start_date' == \$(this).attr('id')) {
                        \$(\"#end_date\").datepicker(\"option\", \"minDate\", dateText);
                    }
                    if ('end_date' == \$(this).attr('id')) {
                        \$(\"#start_date\").datepicker(\"option\", \"maxDate\", dateText);
                    }
                }
            }).datepicker(\"setDate\", new Date());
            var lastData;
            var counter = 0;
            var interval = 1000;  // 1000 = 1 second, 3000 = 3 seconds
            function doAjax() {
                \$.ajax({
                    type: 'POST',
                    url: \"{{ path('log_main') }}\",
                    data: \$(this).serialize(),
                    dataType: 'json',
                    success: function (data) {
                        if (lastData === data) {
                            counter++;
                            if (counter > 4) {
                                \$('.lds-dual-ring').hide();
                                \$('#scrape').prop('disabled', false);
                                \$('#scraper-running').text(\"Scrapper ready to run.\");
                            }
                        } else {
                            if (lastData != null) {
                                \$('.lds-dual-ring').show();
                                \$('#scrape').prop('disabled', true);
                                \$('#scraper-running').text(\"Scrapper is running.\");
                                counter = 0;
                            }
                        }
                        \$('.results').text(\"\").append(data);// first set the value
                        lastData = data;
                    },
                    complete: function (data) {
                        // Schedule the next
                        setTimeout(doAjax, interval);
                    }
                });
            }

            setTimeout(doAjax, interval);
        });
    </script>
{% endblock %}

", "parser/scrape.html.twig", "/var/www/horse/public_html/templates/parser/scrape.html.twig");
    }
}
