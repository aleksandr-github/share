<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* parser/results.html.twig */
class __TwigTemplate_26b669657cae93653cfb6249210b03ea5f9f6875096e797ce246e6b6b81938dc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "parser/results.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "parser/results.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "parser/results.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->loadTemplate("partial/nav_parser.html.twig", "parser/results.html.twig", 4)->display($context);
        // line 5
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">
                <h1>Scrapping for `results` table</h1>
                <form method=\"post\" id=\"scrapper-form\">
                    <div class=\"form-group\">
                        <label for=\"date\">Select date</label>
                        <input type=\"text\" name=\"date\" class=\"form-control\" id=\"date\" placeholder=\"Select date\" required>
                    </div>
                    <button type=\"submit\" class=\"btn btn-primary\" id=\"scrape\">Scrape</button>
                </form>

                <div class=\"alert alert-info\" role=\"alert\" id=\"scraper-running\">
                    Scraper initializing.
                </div>

                <div class=\"row\" style=\"margin-top: 20px; background-color: #2b2b2b; color: #999999; font-family: 'Lucida Console', sans-serif; height: 500px; width: 800px; font-size: 11px;\">
                    <div class=\"results\"></div>
                    <div class=\"lds-dual-ring\"></div>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 31
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 32
        echo "    <script>
        \$(document).ready(function(){
            \$(\"#scrape\").on(\"click\", function(e){
                e.preventDefault();
                \$.ajax({
                    type: 'POST',
                    url: \"";
        // line 38
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("parser_parse_results");
        echo "\",
                    data: \$('#scrapper-form').serialize(),
                    dataType: 'json',
                    success: function (data) {
                        console.log(\"SUCCESS!\");
                    },
                    complete: function (data) {
                        console.log(\"COMPLETE\");
                    },
                    timeout: function (data) {
                        console.log(\"TIMEOUT\");
                    }
                });
            });
        });

        \$( function() {
            \$( \"#date\" ).datepicker({maxDate: '0'}).datepicker(\"setDate\", new Date());
        } );

        var lastData;
        var counter = 0;
        var interval = 1000;  // 1000 = 1 second, 3000 = 3 seconds
        function doAjax() {
            \$.ajax({
                type: 'GET',
                url: \"";
        // line 64
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("log_results");
        echo "\",
                data: \$(this).serialize(),
                dataType: 'json',
                success: function (data) {
                    if (lastData === data) {
                        counter++;
                        if (counter > 4) {
                            \$('.lds-dual-ring').hide();
                            \$('#scrape').prop('disabled', false);
                            \$('#scraper-running').text(\"Scrapper ready to run.\");
                        }
                    } else {
                        \$('.lds-dual-ring').show();
                        \$('#scrape').prop('disabled', true);
                        \$('#scraper-running').text(\"Scrapper is running.\");
                        counter = 0;
                    }
                    \$('.results').text(\"\").append(data);// first set the value
                    lastData = data;
                },
                complete: function (data) {
                    // Schedule the next
                    setTimeout(doAjax, interval);
                }
            });
        }
        setTimeout(doAjax, interval);
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "parser/results.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 64,  124 => 38,  116 => 32,  106 => 31,  72 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {% include 'partial/nav_parser.html.twig' %}

    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-8 col-md-offset-2\">
                <h1>Scrapping for `results` table</h1>
                <form method=\"post\" id=\"scrapper-form\">
                    <div class=\"form-group\">
                        <label for=\"date\">Select date</label>
                        <input type=\"text\" name=\"date\" class=\"form-control\" id=\"date\" placeholder=\"Select date\" required>
                    </div>
                    <button type=\"submit\" class=\"btn btn-primary\" id=\"scrape\">Scrape</button>
                </form>

                <div class=\"alert alert-info\" role=\"alert\" id=\"scraper-running\">
                    Scraper initializing.
                </div>

                <div class=\"row\" style=\"margin-top: 20px; background-color: #2b2b2b; color: #999999; font-family: 'Lucida Console', sans-serif; height: 500px; width: 800px; font-size: 11px;\">
                    <div class=\"results\"></div>
                    <div class=\"lds-dual-ring\"></div>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script>
        \$(document).ready(function(){
            \$(\"#scrape\").on(\"click\", function(e){
                e.preventDefault();
                \$.ajax({
                    type: 'POST',
                    url: \"{{ path('parser_parse_results') }}\",
                    data: \$('#scrapper-form').serialize(),
                    dataType: 'json',
                    success: function (data) {
                        console.log(\"SUCCESS!\");
                    },
                    complete: function (data) {
                        console.log(\"COMPLETE\");
                    },
                    timeout: function (data) {
                        console.log(\"TIMEOUT\");
                    }
                });
            });
        });

        \$( function() {
            \$( \"#date\" ).datepicker({maxDate: '0'}).datepicker(\"setDate\", new Date());
        } );

        var lastData;
        var counter = 0;
        var interval = 1000;  // 1000 = 1 second, 3000 = 3 seconds
        function doAjax() {
            \$.ajax({
                type: 'GET',
                url: \"{{ path('log_results') }}\",
                data: \$(this).serialize(),
                dataType: 'json',
                success: function (data) {
                    if (lastData === data) {
                        counter++;
                        if (counter > 4) {
                            \$('.lds-dual-ring').hide();
                            \$('#scrape').prop('disabled', false);
                            \$('#scraper-running').text(\"Scrapper ready to run.\");
                        }
                    } else {
                        \$('.lds-dual-ring').show();
                        \$('#scrape').prop('disabled', true);
                        \$('#scraper-running').text(\"Scrapper is running.\");
                        counter = 0;
                    }
                    \$('.results').text(\"\").append(data);// first set the value
                    lastData = data;
                },
                complete: function (data) {
                    // Schedule the next
                    setTimeout(doAjax, interval);
                }
            });
        }
        setTimeout(doAjax, interval);
    </script>
{% endblock %}

", "parser/results.html.twig", "/var/www/horse/public_html/templates/parser/results.html.twig");
    }
}
