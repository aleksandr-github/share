<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partial/nav.html.twig */
class __TwigTemplate_3f7fca889d6c11bc26d1bba64c643c271d97118ea02e50981a2f70806d6efc04 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partial/nav.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partial/nav.html.twig"));

        // line 1
        echo "<ul>
    <li><a href=\"";
        // line 2
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index");
        echo "\">Home</a></li>
    <li>
        <a href=\"";
        // line 4
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("horse_index");
        echo "\" ";
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "request", [], "any", false, false, false, 4), "attributes", [], "any", false, false, false, 4), "get", [0 => "_route"], "method", false, false, false, 4), "horse_index"))) {
            echo "class='active'";
        }
        echo ">
            Horses
        </a>
    </li>
    <li>
        <a href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("meeting_index");
        echo "\" ";
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 9, $this->source); })()), "request", [], "any", false, false, false, 9), "attributes", [], "any", false, false, false, 9), "get", [0 => "_route"], "method", false, false, false, 9), "meeting_index"))) {
            echo "class='active'";
        }
        echo ">
            Meetings
        </a>
    </li>

    ";
        // line 14
        if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 14, $this->source); })()), "session", [], "any", false, false, false, 14), "get", [0 => "meeting_id"], "method", false, false, false, 14))) {
            // line 15
            echo "        <li><a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_index", ["meeting" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 15, $this->source); })()), "session", [], "any", false, false, false, 15), "get", [0 => "meeting_id"], "method", false, false, false, 15)]), "html", null, true);
            echo "\">Races</a></li>
        <li><a class=\"active\">";
            // line 16
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "session", [], "any", false, false, false, 16), "get", [0 => "meeting_name"], "method", false, false, false, 16), "html", null, true);
            echo "</a></li>

        ";
            // line 18
            if ((isset($context["races"]) || array_key_exists("races", $context))) {
                // line 19
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["races"]) || array_key_exists("races", $context) ? $context["races"] : (function () { throw new RuntimeError('Variable "races" does not exist.', 19, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["race"]) {
                    // line 20
                    echo "                <li>
                    ";
                    // line 21
                    if ((isset($context["raceId"]) || array_key_exists("raceId", $context))) {
                        // line 22
                        echo "                        <a href=\"";
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_details", ["meeting" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "session", [], "any", false, false, false, 22), "get", [0 => "meeting_id"], "method", false, false, false, 22), "race" => twig_get_attribute($this->env, $this->source, $context["race"], "race_id", [], "any", false, false, false, 22)]), "html", null, true);
                        echo "\"
                           ";
                        // line 23
                        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["race"], "race_id", [], "any", false, false, false, 23), (isset($context["raceId"]) || array_key_exists("raceId", $context) ? $context["raceId"] : (function () { throw new RuntimeError('Variable "raceId" does not exist.', 23, $this->source); })())))) {
                            echo "class=\"active\"";
                        }
                        echo ">
                            ";
                        // line 24
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["race"], "race_order", [], "any", false, false, false, 24), "html", null, true);
                        echo "
                        </a>
                    ";
                    } else {
                        // line 27
                        echo "                        <a href=\"";
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_details", ["meeting" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 27, $this->source); })()), "session", [], "any", false, false, false, 27), "get", [0 => "meeting_id"], "method", false, false, false, 27), "race" => twig_get_attribute($this->env, $this->source, $context["race"], "race_id", [], "any", false, false, false, 27)]), "html", null, true);
                        echo "\">
                            ";
                        // line 28
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["race"], "race_order", [], "any", false, false, false, 28), "html", null, true);
                        echo "
                        </a>
                    ";
                    }
                    // line 31
                    echo "                </li>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['race'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 33
                echo "        ";
            }
            // line 34
            echo "
        ";
            // line 35
            if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 35, $this->source); })()), "request", [], "any", false, false, false, 35), "attributes", [], "any", false, false, false, 35), "get", [0 => "_route"], "method", false, false, false, 35), "races_details"))) {
                // line 36
                echo "            ";
                if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 36, $this->source); })()), "request", [], "any", false, false, false, 36), "get", [0 => "avg"], "method", false, false, false, 36), 1))) {
                    // line 37
                    echo "                <li class=\"pull-right\">
                    <a href=\"";
                    // line 38
                    echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("horse_index");
                    echo "\" class=\"dropdown-item active\">Show Horses</a>
                </li>
                <li class=\"pull-right\">
                    <a href=\"";
                    // line 41
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_details", ["race" => (isset($context["raceId"]) || array_key_exists("raceId", $context) ? $context["raceId"] : (function () { throw new RuntimeError('Variable "raceId" does not exist.', 41, $this->source); })()), "meeting" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 41, $this->source); })()), "session", [], "any", false, false, false, 41), "get", [0 => "meeting_id"], "method", false, false, false, 41)]), "html", null, true);
                    echo "\" class=\"dropdown-item active\">Show All</a>
                </li>
            ";
                } else {
                    // line 44
                    echo "                <li class=\"pull-right\">
                    <a href=\"";
                    // line 45
                    echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("horse_index");
                    echo "\" class=\"dropdown-item active\">Show Horses</a>
                </li>
                <li class=\"pull-right\">
                    <a href=\"";
                    // line 48
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_details", ["race" => (isset($context["raceId"]) || array_key_exists("raceId", $context) ? $context["raceId"] : (function () { throw new RuntimeError('Variable "raceId" does not exist.', 48, $this->source); })()), "meeting" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 48, $this->source); })()), "session", [], "any", false, false, false, 48), "get", [0 => "meeting_id"], "method", false, false, false, 48)]), "html", null, true);
                    echo "?avg=1\" class=\"dropdown-item active\">Show Average</a>
                </li>
            ";
                }
                // line 51
                echo "        ";
            }
            // line 52
            echo "    ";
        }
        // line 53
        echo "</ul>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partial/nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 53,  178 => 52,  175 => 51,  169 => 48,  163 => 45,  160 => 44,  154 => 41,  148 => 38,  145 => 37,  142 => 36,  140 => 35,  137 => 34,  134 => 33,  127 => 31,  121 => 28,  116 => 27,  110 => 24,  104 => 23,  99 => 22,  97 => 21,  94 => 20,  89 => 19,  87 => 18,  82 => 16,  77 => 15,  75 => 14,  63 => 9,  51 => 4,  46 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<ul>
    <li><a href=\"{{ path('index') }}\">Home</a></li>
    <li>
        <a href=\"{{ path('horse_index') }}\" {% if app.request.attributes.get('_route') == 'horse_index' %}class='active'{% endif %}>
            Horses
        </a>
    </li>
    <li>
        <a href=\"{{ path('meeting_index') }}\" {% if app.request.attributes.get('_route') == 'meeting_index' %}class='active'{% endif %}>
            Meetings
        </a>
    </li>

    {% if app.session.get('meeting_id') is not empty %}
        <li><a href=\"{{ path('races_index', { 'meeting': app.session.get('meeting_id') }) }}\">Races</a></li>
        <li><a class=\"active\">{{ app.session.get('meeting_name') }}</a></li>

        {% if races is defined %}
            {% for race in races %}
                <li>
                    {% if raceId is defined %}
                        <a href=\"{{ path('races_details', { 'meeting': app.session.get('meeting_id'), 'race': race.race_id}) }}\"
                           {% if race.race_id == raceId %}class=\"active\"{% endif %}>
                            {{ race.race_order }}
                        </a>
                    {% else %}
                        <a href=\"{{ path('races_details', { 'meeting': app.session.get('meeting_id'), 'race': race.race_id}) }}\">
                            {{ race.race_order }}
                        </a>
                    {% endif %}
                </li>
            {% endfor %}
        {% endif %}

        {% if app.request.attributes.get('_route') == 'races_details' %}
            {% if app.request.get('avg') == 1 %}
                <li class=\"pull-right\">
                    <a href=\"{{ path('horse_index') }}\" class=\"dropdown-item active\">Show Horses</a>
                </li>
                <li class=\"pull-right\">
                    <a href=\"{{ path('races_details', {'race': raceId, 'meeting': app.session.get('meeting_id')}) }}\" class=\"dropdown-item active\">Show All</a>
                </li>
            {% else %}
                <li class=\"pull-right\">
                    <a href=\"{{ path('horse_index') }}\" class=\"dropdown-item active\">Show Horses</a>
                </li>
                <li class=\"pull-right\">
                    <a href=\"{{ path('races_details', {'race': raceId, 'meeting': app.session.get('meeting_id')}) }}?avg=1\" class=\"dropdown-item active\">Show Average</a>
                </li>
            {% endif %}
        {% endif %}
    {% endif %}
</ul>", "partial/nav.html.twig", "/var/www/horse/public_html/templates/partial/nav.html.twig");
    }
}
