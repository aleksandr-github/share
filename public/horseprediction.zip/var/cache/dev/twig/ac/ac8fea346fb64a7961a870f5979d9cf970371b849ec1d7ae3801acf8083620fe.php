<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* horse.html.twig */
class __TwigTemplate_d83c49ec4145ed10c524aab01e12f2e8d7dc838f3822e79e56be040de2c75f51 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "horse.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "horse.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "horse.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->loadTemplate("partial/nav.html.twig", "horse.html.twig", 4)->display($context);
        // line 5
        echo "    <div class=\"container\">
        <div class=\"panel-group\">
            <div class=\"panel panel-primary\">
                <div class=\"panel-heading\">";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 8, $this->source); })()), "horseName", [], "any", false, false, false, 8), "html", null, true);
        echo " #";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 8, $this->source); })()), "horseId", [], "any", false, false, false, 8), "html", null, true);
        echo "</div>
                <div class=\"panel-body\">

                    <table id=\"employee_grid_2\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                        <tbody>
                            <tr>
                                <td>Horse Name: ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 14, $this->source); })()), "horseName", [], "any", false, false, false, 14), "html", null, true);
        echo "</td>
                                <td>Horse Slug: ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 15, $this->source); })()), "horseSlug", [], "any", false, false, false, 15), "html", null, true);
        echo "></td>
                                <td>Horse Latest Results: ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 16, $this->source); })()), "horseLatestResults", [], "any", false, false, false, 16), "html", null, true);
        echo "</td>
                                <td>Added On: ";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 17, $this->source); })()), "horseAddedOn", [], "any", false, false, false, 17), "html", null, true);
        echo "</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

        </div>

        <div class=\"\">
            <h1>Meetings Data</h1>
            <div class=\"\">
                <table id=\"employee_grid\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                    <thead>
                    <tr>
                        <th>Meeting Date</th>
                        <th>Meeting Name</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["horseDetails"]) || array_key_exists("horseDetails", $context) ? $context["horseDetails"] : (function () { throw new RuntimeError('Variable "horseDetails" does not exist.', 38, $this->source); })()), "meetings", [], "any", false, false, false, 38));
        foreach ($context['_seq'] as $context["_key"] => $context["meeting"]) {
            // line 39
            echo "                        <tr>
                            <td>";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["meeting"], "meetingDate", [], "any", false, false, false, 40), "html", null, true);
            echo "</td>
                            <td>
                                <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("races_index", ["meeting" => twig_get_attribute($this->env, $this->source, $context["meeting"], "meetingId", [], "any", false, false, false, 42)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["meeting"], "meetingName", [], "any", false, false, false, 42), "html", null, true);
            echo "</a>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['meeting'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Meeting Date</th>
                        <th>Meeting Name</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "    <script type=\"text/javascript\">
        \$(document).ready(function () {
            \$('#employee_grid').DataTable({
                \"responsive\": true,
            });
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "horse.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  179 => 60,  169 => 59,  148 => 46,  136 => 42,  131 => 40,  128 => 39,  124 => 38,  100 => 17,  96 => 16,  92 => 15,  88 => 14,  77 => 8,  72 => 5,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {% include 'partial/nav.html.twig' %}
    <div class=\"container\">
        <div class=\"panel-group\">
            <div class=\"panel panel-primary\">
                <div class=\"panel-heading\">{{ horseDetails.horseName }} #{{ horseDetails.horseId}}</div>
                <div class=\"panel-body\">

                    <table id=\"employee_grid_2\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                        <tbody>
                            <tr>
                                <td>Horse Name: {{ horseDetails.horseName }}</td>
                                <td>Horse Slug: {{ horseDetails.horseSlug }}></td>
                                <td>Horse Latest Results: {{ horseDetails.horseLatestResults }}</td>
                                <td>Added On: {{ horseDetails.horseAddedOn }}</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

        </div>

        <div class=\"\">
            <h1>Meetings Data</h1>
            <div class=\"\">
                <table id=\"employee_grid\" class=\"display\" width=\"100%\" cellspacing=\"0\">
                    <thead>
                    <tr>
                        <th>Meeting Date</th>
                        <th>Meeting Name</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% for meeting in horseDetails.meetings %}
                        <tr>
                            <td>{{ meeting.meetingDate }}</td>
                            <td>
                                <a href=\"{{ path('races_index', {'meeting': meeting.meetingId}) }}\">{{ meeting.meetingName }}</a>
                            </td>
                        </tr>
                    {% endfor %}
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Meeting Date</th>
                        <th>Meeting Name</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\">
        \$(document).ready(function () {
            \$('#employee_grid').DataTable({
                \"responsive\": true,
            });
        });
    </script>
{% endblock %}

", "horse.html.twig", "/var/www/horse/public_html/templates/horse.html.twig");
    }
}
