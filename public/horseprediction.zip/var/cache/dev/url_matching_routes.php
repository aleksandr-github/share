<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/admin/truncate_tables' => [[['_route' => 'admin_truncate_tables', '_controller' => 'App\\Controller\\Admin\\AdminController::truncateTables'], null, null, null, false, false, null]],
        '/admin/truncate_logs' => [[['_route' => 'admin_truncate_logs', '_controller' => 'App\\Controller\\Admin\\AdminController::truncateLogs'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\HomeController::show'], null, null, null, false, false, null]],
        '/horse' => [[['_route' => 'horse_index', '_controller' => 'App\\Controller\\HorseController::index'], null, null, null, false, false, null]],
        '/meeting' => [[['_route' => 'meeting_index', '_controller' => 'App\\Controller\\MeetingController::index'], null, null, null, false, false, null]],
        '/log/main' => [[['_route' => 'log_main', '_controller' => 'App\\Controller\\Parser\\LogController::obtainMainLog'], null, null, null, false, false, null]],
        '/log/results' => [[['_route' => 'log_results', '_controller' => 'App\\Controller\\Parser\\LogController::obtainResultsLog'], null, null, null, false, false, null]],
        '/parser' => [[['_route' => 'parser_main', '_controller' => 'App\\Controller\\Parser\\ParserController::scrape'], null, null, null, false, false, null]],
        '/parser/scrape' => [[['_route' => 'parser_scrape_data', '_controller' => 'App\\Controller\\Parser\\ParserController::scrapeData'], null, ['POST' => 0], null, false, false, null]],
        '/parser/results' => [[['_route' => 'parser_results', '_controller' => 'App\\Controller\\Parser\\ResultsController::results'], null, null, null, false, false, null]],
        '/parser/parse_results' => [[['_route' => 'parser_parse_results', '_controller' => 'App\\Controller\\Parser\\ResultsController::parseResults'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/horse/([^/]++)(*:184)'
                .'|/races/meeting/([^/]++)(?'
                    .'|/race/([^/]++)(*:232)'
                    .'|(*:240)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        184 => [[['_route' => 'horse_details', '_controller' => 'App\\Controller\\HorseController::showOne'], ['horse'], null, null, false, true, null]],
        232 => [[['_route' => 'races_details', '_controller' => 'App\\Controller\\RaceController::showOne'], ['meeting', 'race'], null, null, false, true, null]],
        240 => [
            [['_route' => 'races_index', '_controller' => 'App\\Controller\\RaceController::showAll'], ['meeting'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
