<?php

namespace App\Command;

use App\Model\DateRange;
use App\Model\ScraperSummary;
use App\Service\ParserService;
use DateTime;
use mysqli;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Dotenv\Dotenv;

class RunScraperCommand extends Command
{
    protected static $defaultName = 'run:scraper';

    protected $parserService;

    public function __construct(ParserService $parserService)
    {
        $this->parserService = $parserService;

        parent::__construct();
    }

    protected function configure()
    {
        $this->setDescription('Runs parser in CLI mode for pthreads implementation.')
            ->setHelp('Runs parser in CLI mode for pthreads implementation.')
            ->addArgument('startDate', InputArgument::REQUIRED, 'Starting date (in Y-m-d format)')
            ->addArgument('endDate', InputArgument::OPTIONAL, 'Ending date (in Y-m-d format)');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        if (extension_loaded('pthreads')) {
            $io->warning('php_pthreads extension is considered abandoned and deprecated. Use php_parallel instead.');
        } elseif (extension_loaded('parallel')) {
            $io->success('Parallel extension initialized');
        } else {
            //throw new \Exception('It seems you have pThreads disabled. Console command available only on system with pThreads extension!');
            $io->warning("pThreads // Parallel not found. Results may vary. Consider installing php_parallel extension");
        }

        if (empty($input->getArgument('endDate'))) {
            $input->setArgument('endDate', $input->getArgument('startDate'));
        }

        $dateRange = new DateRange();
        $dates = $this->createDatesRange($input->getArgument('startDate'), $input->getArgument('endDate'));

        foreach ($dates as $dateKey => $date) {
            $dateRange->add($date);
        }

        if ($this->isRecordsInDBForDateRange($dateRange)) {
            $io->error("Data already exists for selected dates.");

            return Command::FAILURE;
        }

        $io->text("Started parsing, please wait. You can check logs/main_log.txt to see progress in real time.");

        try {
            $results = $this->parserService->startParser($input->getArgument('startDate'), $input->getArgument('endDate'));
        } catch (\Throwable $e) {
            $io->error($e->getMessage());
            $io->note($e->getTraceAsString());
            while ($e = $e->getPrevious()) {
                $io->note($e->getTraceAsString());
                $io->error($e->getMessage());
            }

            return Command::FAILURE;
        }

        $this->showResults($results, $io);
        $io->success("Parser finished. Check main_log.txt for details.");

        return Command::SUCCESS;
    }

    protected function isRecordsInDBForDateRange(DateRange $dateRange)
    {
        $mysqli = $this->initMultiSessionDatabase();
        $query = "SELECT COUNT(meeting_id) FROM `tbl_meetings` WHERE meeting_date IN (".$dateRange->toSQLQuery().")";
        $res = $mysqli->query($query);
        $num_rows = $res->fetch_array();
        $count = $num_rows[0];
        if ($count > 0) {
            return true;
        }

        return false;
    }

    private function createDatesRange($start, $end, $format = 'Y-m-d')
    {
        $start = new DateTime($start);
        $end = new DateTime($end);
        $invert = $start > $end;
        $dates = array();
        $dates[] = $start->format($format);
        while ($start != $end) {
            $start->modify(($invert ? '-' : '+') . '1 day');
            $dates[] = $start->format($format);
        }
        return $dates;
    }

    /**
     * @return mysqli
     */
    protected function initMultiSessionDatabase(): mysqli
    {
        (new Dotenv())->bootEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '.env');

        $mysqli = new mysqli(
            $_ENV["dbservername"],
            $_ENV["dbusername"],
            $_ENV["dbpassword"],
            $_ENV["dbdatabase"]
        );
        $mysqli->ping();

        return $mysqli;
    }

    private function showResults(ScraperSummary $scraperSummary, SymfonyStyle $io)
    {
        $micro = sprintf("%06d",($scraperSummary->getAlgStart() - floor($scraperSummary->getAlgStart())) * 1000000);
        $d = new DateTime( date('Y-m-d H:i:s.'.$micro, $scraperSummary->getAlgStart()) );
        $now = new DateTime();
        $diff = $now->diff($d);
        $diffSeconds = microtime(true) - $scraperSummary->getAlgStart();

        $io->writeln("");
        $io->title("SCRAPER SUMMARY");
        $io->table(["Description", "Time"], [
            ["(❍ᴥ❍ʋ) Scraper started at", $d->format("Y-m-d H:i:s.u")],
            ["Parsing race results in dates", $scraperSummary->getDateRange()->__toString()],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getMeetingsTimeEnd(), $diffSeconds) . "%] Meetings workers parsing time", number_format($scraperSummary->getMeetingsTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getRacesTimeEnd(), $diffSeconds) . "%] Races workers parsing time", number_format($scraperSummary->getRacesTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getHorsesTimeEnd(), $diffSeconds) . "%] Horses workers parsing time", number_format($scraperSummary->getHorsesTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getHorsesRecordsTimeEnd(), $diffSeconds) . "%] Records workers parsing time", number_format($scraperSummary->getHorsesRecordsTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getResultsTimeEnd(), $diffSeconds) . "%] Records workers saving time", number_format($scraperSummary->getResultsTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getHistoricResultsTimeEnd(), $diffSeconds) . "%] Historic Results workers parsing time", number_format($scraperSummary->getHistoricResultsTimeEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getHandicapRecalculationsStartEnd(), $diffSeconds) . "%] Handicap recalculation workers time", number_format($scraperSummary->getHandicapRecalculationsStartEnd(), 2) . " seconds"],
            ["[" . $this->getPercentageOfValueInTotal($scraperSummary->getDistanceUpdateTimeEnd(), $diffSeconds) . "%] Distance update workers time", number_format($scraperSummary->getDistanceUpdateTimeEnd(), 2) . " seconds"]
        ]);

        $io->text("♪┏(°.°)┛┗(°.°)┓┗(°.°)┛┏(°.°)┓ ♪");
        $io->title('୧༼◕ ᴥ ◕༽୨ Scraper took ' . $diff->format("%i minutes and %s seconds") . " overall to complete");
    }

    protected function getPercentageOfValueInTotal(int $value, int $total)
    {
        return (int)($value / $total * 100);
    }
}