<?php

namespace App\Helper;

class ArrayObjectHelper
{
    public static function convertToArray($object): array
    {
        return (array)$object;
    }

    public static function covertToObject($array): object
    {
        return (object)$array;
    }
}