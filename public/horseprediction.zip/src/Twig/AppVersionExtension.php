<?php

namespace App\Twig;

use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class AppVersionExtension extends AbstractExtension
{
    public function getFunctions()
    {
        return [
            new TwigFunction('appVersion', [$this, 'appVersion']),
        ];
    }

    public function appVersion(): string
    {
        return 'v0.9';
    }
}