<?php

namespace App\Service;

use App\Model\DBCredentials;
use mysqli;
use stdClass;

class DBConnector
{
    /** @var mysqli */
    private $dbConnection;
    /** @var PrettyLogger */
    private $dbLogger;

    public function __construct()
    {
        $credentials = $this->initDBCredentials();

        if (!$this->dbConnection) {
            $this->dbConnection = new mysqli(
                $credentials->getServername(),
                $credentials->getUsername(),
                $credentials->getPassword(),
                $credentials->getDatabase()
            );
        }
        $this->dbLogger = new PrettyLogger(__FILE__, "db_logs.txt");
    }

    /**
     * @return DBCredentials
     */
    public function initDBCredentials(): DBCredentials
    {
        $dbCredentials = new DBCredentials();
        $dbCredentials->setServername($_ENV['dbservername']);
        $dbCredentials->setDatabase($_ENV['dbdatabase']);
        $dbCredentials->setUsername($_ENV['dbusername']);
        $dbCredentials->setPassword($_ENV['dbpassword']);

        return $dbCredentials;
    }

    /**
     * @return mysqli
     */
    public function getDbConnection(): mysqli
    {
        return $this->dbConnection;
    }

    /**
     * Gets number of rows of a query
     * @TODO it's unefficient and can be done better
     *
     * @param $table_and_query
     * @return int
     */
    public function get_rows($table_and_query)
    {
        $total = $this->dbConnection->query("SELECT * FROM $table_and_query");
        $total = $total->num_rows;

        return $total;
    }

    /**
     * @param $mid
     * @return object|stdClass
     */
    public function meeting_details($mid)
    {
        $meetingdet = $this->dbConnection->query("SELECT * FROM `tbl_meetings` WHERE `meeting_id`='$mid'");
        $detail = $meetingdet->fetch_object();

        return $detail;
    }

    /**
     * @param $hid
     * @return object|stdClass
     */
    public function horse_details($hid)
    {
        $horsedet = $this->dbConnection->query("SELECT * FROM `tbl_horses` WHERE `horse_id`='$hid'");
        $detail = $horsedet->fetch_object();

        return $detail;
    }

    /**
     * @param $rid
     * @return object|stdClass
     */
    public function race_details($rid)
    {
        $racedet = $this->dbConnection->query("SELECT * FROM `tbl_races` WHERE `race_id`='$rid'");
        $detail = $racedet->fetch_object();

        return $detail;
    }

    /**
     * Get an item from an array by key.
     *
     * Return a default value in a case when the item is not in an array.
     *
     * @param array $data
     * @param string $key
     * @param null $defaultValue
     *
     * @return mixed|null
     */
    function arrayGet(array $data, $key, $defaultValue = null)
    {
        return (isset($data[$key])) ? $data[$key] : $defaultValue;
    }

    /**
     * Run multiple queries.
     *
     * The queries queries must be concatenated by a semicolon.
     *
     * @param string $dbTable
     * @param string $query
     * @param int $queriesCount
     *
     * @return bool False in a case of error
     */
    public function runMultipleQuery($dbTable, $query, $queriesCount = 0)
    {
        $this->dbLogger->log("Run update queries on $dbTable. Total queries: $queriesCount");

        if (empty($query)) {
            $this->dbLogger->log("Query is empty", 'debug');
        }

        $multipleUpdate = $this->dbConnection->multi_query($query);
        if (!$multipleUpdate) {
            $this->dbLogger->log($this->dbConnection->error, 'error');
            $this->dbLogger->log($query, 'debug');

            return false;
        } else {
            while ($this->dbConnection->next_result()) // flush multi_queries
            {
                if (!$this->dbConnection->more_results()) {
                    break;
                }
            }
            $this->dbLogger->log($query, 'debug');
        }

        return true;
    }

    public function getMeetingsForIDs($meetingsIds): array
    {
        $strMeetings = implode(",", $meetingsIds);
        $sql = "SELECT * FROM tbl_meetings WHERE meeting_id IN (".$strMeetings.")";
        $stmt = $this->dbConnection->query($sql);

        return $stmt->fetch_all(MYSQLI_ASSOC);
    }

    public function getRacesForIDs($racesIds): array
    {
        $strRaces = implode(",", $racesIds);
        $sql = "SELECT * FROM tbl_races WHERE race_id IN (".$strRaces.")";
        $stmt = $this->dbConnection->query($sql);

        return $stmt->fetch_all(MYSQLI_ASSOC);
    }

    public function getHorsesForIDs($horsesIDs): array
    {
        $strHorses = implode(",", $horsesIDs);
        $sql = "SELECT * FROM tbl_horses WHERE horse_id IN (".$strHorses.")";
        $stmt = $this->dbConnection->query($sql);

        return $stmt->fetch_all(MYSQLI_ASSOC);
    }

    public function getResultsForHistoricIDs($historicRecordsIDs)
    {
        $strResults = implode(",", $historicRecordsIDs);
        $sql = "SELECT * FROM tbl_hist_results WHERE tbl_hist_results.hist_id IN (".$strResults.")";
        $stmt = $this->dbConnection->query($sql);

        return $stmt->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * @param string $implode
     * @return array
     */
    public function multiQueryInsertIDs(string $implode): array
    {
        $this->dbConnection->multi_query($implode);

        $ids = array();
        do
        {
            $ids[] = $this->dbConnection->insert_id;
            $this->dbConnection->next_result();
        } while($this->dbConnection->more_results());

        return $ids;
    }
}