<?php

namespace App\Service;

use Exception;

class AlgorithmFunctions
{
    /** @var DBConnector */
    protected $db;

    /** @var PrettyLogger */
    protected $logger;

    protected $timer;

    public function __construct(DBConnector $connector)
    {
        $this->db = $connector;
        try {
            $this->logger = new PrettyLogger(__FILE__, 'main_logs.txt');
        } catch (Exception $e) {
            die($e->getMessage());
        }

        $this->timer = 0.0007;
    }

    /**
     * @param $position_percentage
     * @param int $limit
     * @param int $raceId
     */
    function updatehptime($position_percentage, $limit = 0, $raceId = 0)
    {
        $this->logger->log('Started: ' . __FUNCTION__);

        if ($raceId) {
            $q = "SELECT `race_id` 
              FROM `tbl_races` 
              WHERE `race_id`='" . $raceId . "' 
              ORDER by `race_id` ASC";
        } else {
            if ($limit == "0") {
                $q = "SELECT `race_id` 
                  FROM `tbl_races` 
                  WHERE `rank_status`='0' 
                  ORDER by `race_id` ASC";
            } else {
                $q = "SELECT `race_id` 
                  FROM `tbl_races` 
                  WHERE `rank_status`='0' 
                  ORDER by `race_id` ASC LIMIT $limit";
            }
        }
        $races = $this->db->getDbConnection()->query($q);
        $updateQuery = "";
        $updateQueryCount = 0;
        $updateQueryRaces = "";
        $updateQueryRacesCount = 0;

        // Rank
        if ($races->num_rows > 0)
        {
            $this->logger->log('Start calculation of the rank');
            if ($raceId) $this->logger->log('RaceID is ' . $raceId);

            while ($race = $races->fetch_object())
            {
                $horsesCount = $this->db->get_rows(
                    "`tbl_temp_hraces` 
                WHERE `race_id`='$race->race_id' 
                AND `horse_fxodds`!='0'"
                );

                $qDistance = "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                          FROM tbl_hist_results 
                          WHERE `race_id`='$race->race_id' 
                          ORDER by racedist ASC";
                $distances = $this->db->getDbConnection()->query($qDistance);

                $this->logger->log('Rank. All below results are for Race ID: ' . $race->race_id, 'debug');
                $this->logger->log($qDistance, 'debug');

                while ($distance = $distances->fetch_object())
                {
                    $numsArray = $this->get_array_of_handicap(
                        $race->race_id,
                        $distance->racedist
                    );
                    $cnt = count($numsArray);

                    $horsesHistResult = $this->db->getDbConnection()->query(
                        "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`='$race->race_id' 
                     AND `race_distance`='$distance->racedist'"
                    );

                    $i = 1;
                    while ($horse = $horsesHistResult->fetch_object()) {
                        $oddsResult = $this->db->getDbConnection()->query(
                            "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`='$race->race_id' 
                         AND `horse_id`='$horse->horse_id'"
                        );

                        if ($oddsResult->num_rows === 0) continue;
                        $odds = $oddsResult->fetch_object();

                        if (isset($odds->horse_fxodds)
                            && $odds->horse_fxodds != "0"
                        ) {
                            $handicapResults = $this->db->getDbConnection()->query(
                                "SELECT MIN(handicap) as minihandi 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`='$race->race_id' 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horse->horse_id'"
                            );

                            while ($row = $handicapResults->fetch_object()) {
                                if ($horsesCount > 0) {
                                    $per = ($cnt / $horsesCount) * 100;

                                    if ($per > $position_percentage) {
                                        $rank = $this->generate_rank(
                                            $row->minihandi,
                                            $numsArray
                                        );

                                        $updateQuery .= "UPDATE `tbl_hist_results` 
                                                    SET `rank`='$rank' 
                                                    WHERE `race_id`='$race->race_id' 
                                                    AND `race_distance`= '$distance->racedist' 
                                                    AND `horse_id`='$horse->horse_id';";
                                        $updateQueryCount++;
                                    }
                                }
                            }
                            ++$i;
                        }
                    }
                }
                if ($updateQuery) {
                    $updateQueryRaces .= "UPDATE `tbl_races` 
                     SET `rank_status`='1' 
                     WHERE `race_id`='$race->race_id';";
                    $updateQueryRacesCount++;
                }
            }

            $this->logger->log('Finish calculation of the rank');
        } else {
            $this->logger->log('Rank: 0 results');
        }

        // Sectional avg
        if ($raceId) {
            $q = "SELECT `race_id` FROM `tbl_races` WHERE `race_id`='$raceId'";
        } else {
            if ($limit == "0") {
                $q = "SELECT `race_id` 
                  FROM `tbl_races` 
                  WHERE `sec_status`='0' 
                  OR `sec_status`='' 
                  ORDER by `race_id` ASC";
            } else {
                $q = "SELECT `race_id` 
                  FROM `tbl_races` 
                  WHERE `sec_status`='0' 
                  OR `sec_status`='' 
                  ORDER by `race_id` 
                  ASC LIMIT $limit";
            }
        }
        $races = $this->db->getDbConnection()->query($q);
        if ($races->num_rows > 0) {

            $this->logger->log('Start calculation of the Sectional AVG');
            if ($raceId) $this->logger->log('RaceID is ' . $raceId);

            while ($race = $races->fetch_object()) {
                $horsesCount = $this->db->get_rows(
                    "`tbl_temp_hraces` WHERE `race_id`='$race->race_id' AND `horse_fxodds`!='0'"
                );

                $qDistance = "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                          FROM tbl_hist_results 
                          WHERE `race_id`='$race->race_id' 
                          ORDER by racedist ASC";
                $distances = $this->db->getDbConnection()->query($qDistance);

                $this->logger->log('Sectional AVG. All below results are for Race ID: ' . $race->race_id, 'debug');
                $this->logger->log($qDistance, 'debug');

                while ($distance = $distances->fetch_object()) {
                    $numsArray = $this->get_array_of_avgsec($race->race_id,
                        $distance->racedist);
                    $cnt = count($numsArray);

                    $horsesHistResult = $this->db->getDbConnection()->query(
                        "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`='$race->race_id' 
                     AND `race_distance`='$distance->racedist'"
                    );

                    $i = 1;
                    while ($horse = $horsesHistResult->fetch_object()) {
                        $oddsResult = $this->db->getDbConnection()->query(
                            "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`='$race->race_id' 
                         AND `horse_id`='$horse->horse_id'"
                        );
                        if ($oddsResult->num_rows === 0) continue;

                        $odds = $oddsResult->fetch_object();
                        if ($odds->horse_fxodds != "0") {
                            $handicapResults = $this->db->getDbConnection()->query(
                                "SELECT MAX(avgsec) AS secavg 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`='$race->race_id' 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horse->horse_id'"
                            );

                            while ($row = $handicapResults->fetch_object()) {
                                $per = ($cnt / $horsesCount) * 100;

                                if ($per > $position_percentage) {
                                    $avgSectional = $this->generate_avgsectional(
                                        $row->secavg,
                                        $numsArray
                                    );
                                    $updateQuery .= "UPDATE `tbl_hist_results` 
                                                 SET `avgsectional`='$avgSectional' 
                                                 WHERE `race_id`='$race->race_id' 
                                                 AND `race_distance`= '$distance->racedist' 
                                                 AND `horse_id`='$horse->horse_id';";
                                    $updateQueryCount++;
                                }
                            }
                            ++$i;
                        }
                    }
                }
                if ($updateQuery) {
                    $updateQueryRaces .= "UPDATE `tbl_races` 
                     SET `sec_status`='1' 
                     WHERE `race_id`='$race->race_id';";
                    $updateQueryRacesCount++;
                }
            }

            $this->logger->log('Finish calculation of the Sectional AVG');
        } else {
            $this->logger->log('Sectional AVG: 0 results');
        }

        // Execute update queries
        if ($updateQuery) {
            $this->db->runMultipleQuery(
                'tbl_hist_results',
                $updateQuery,
                $updateQueryCount
            );
            $this->db->runMultipleQuery(
                'tbl_races',
                $updateQueryRaces,
                $updateQueryRacesCount
            );

            $updateQuery = "";
            $updateQueryCount = 0;
        } else {
            $this->logger->log('No updates for "tbl_hist_results"');
        }

        // Rating
        if ($raceId) {
            $q = "SELECT * FROM `tbl_hist_results` 
              WHERE `rating`='0' AND `race_id`='$raceId'";
        } else {
            if ($limit == "0") {
                $q = "SELECT * FROM `tbl_hist_results` 
                  WHERE `rating`='0'";
            } else {
                $q = "SELECT * FROM `tbl_hist_results` 
                  WHERE `rating`='0' LIMIT $limit";
            }
        }

        $results = $this->db->getDbConnection()->query($q);
        if ($results->num_rows > 0) {

            $this->logger->log('Start calculation of the rating');
            if ($raceId) $this->logger->log('RaceID is ' . $raceId);

            while ($row = $results->fetch_object()) {
                $logMessage = 'avgsectional: ' . $row->avgsectional . PHP_EOL;
                $logMessage .= 'rank: ' . $row->rank . PHP_EOL;
                $logMessage .= 'hist_id: ' . $row->hist_id;
                $this->logger->log($logMessage, 'debug');

                if ($row->avgsectional != "0" || $row->rank != "0") {
                    $ratePos = $row->avgsectional + $row->rank;
                    // modify by Jfrost
                    $ratePos = $ratePos + $this->h2h_points($row->horse_h2h);
                    $updateQuery .= "UPDATE `tbl_hist_results` 
                                 SET `rating` = '$ratePos' , `temp_h2h` = " . $row->horse_h2h . "
                                 WHERE `hist_id` = '$row->hist_id';";
                    $updateQueryCount++;

                    $this->logger->log('Rating done for: ' . $row->hist_id . 'h2h_points(' . $row->horse_h2h . ')', 'debug');
                }
            }

            if ($updateQuery) {
                $this->db->runMultipleQuery(
                    'tbl_hist_results',
                    $updateQuery,
                    $updateQueryCount
                );
            } else {
                $this->logger->log('No updates for "tbl_hist_results"');
            }

            $this->logger->log('Finish calculation of the rating');
        } else {
            $this->logger->log('Rating: 0 results');
        }

        $this->logger->log('Finished: ' . __FUNCTION__);
    }

    /**
     * @param $position_percentage
     * @param int $distance
     * @param int $raceId
     */
    function distance_new($position_percentage, $distance = 0, $raceId = 0)
    {
        $this->logger->log('Started: ' . __FUNCTION__);

        if ($raceId == 0) {
            $this->logger->log("Race id is $raceId. Exit");
            return;
        }

        $q = "SELECT `race_id` FROM `tbl_races` 
             WHERE `race_id`='$raceId' ORDER by `race_id` ASC";
        $races = $this->db->getDbConnection()->query($q);
        if (!$races) {
            $this->logger->log($this->db->getDbConnection()->error, 'error');
        }

        // Rank
        if ($races->num_rows > 0) {
            while ($race = $races->fetch_object()) {
                $horsesCount = $this->db->get_rows(
                    "`tbl_temp_hraces` 
                 WHERE `race_id`='$race->race_id' 
                 AND `horse_fxodds`!='0'"
                );

                $this->logger->log('Start calculation of the Rank');
                if ($raceId) $this->logger->log('RaceID is ' . $raceId);

                $distancesResult = $this->db->getDbConnection()->query(
                    "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                 FROM tbl_hist_results 
                 WHERE `race_id`='$race->race_id' 
                 AND `race_distance`='$distance' 
                 ORDER by racedist ASC"
                );

                $updateQuery = "";
                $updateQueriesCount = 0;
                while ($distance = $distancesResult->fetch_object()) {
                    $numsArray = $this->get_array_of_handicap($race->race_id, $distance->racedist);
                    $cnt = count($numsArray);
                    $horsesHistResult = $this->db->getDbConnection()->query(
                        "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`='$race->race_id' 
                     AND `race_distance`='$distance->racedist'"
                    );

                    $i = 1;
                    while ($horseHist = $horsesHistResult->fetch_object()) {
                        $odds = $this->db->getDbConnection()->query(
                            "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`='$race->race_id' 
                         AND `horse_id`='$horseHist->horse_id'"
                        );
                        $oddsResult = $odds->fetch_object();

                        if (isset($oddsResult->horse_fxodds)
                            && $oddsResult->horse_fxodds != "0") {
                            $handicapResult = $this->db->getDbConnection()->query(
                                "SELECT MIN(handicap) as minihandi 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`='$race->race_id' 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horseHist->horse_id'"
                            );

                            while ($handicap = $handicapResult->fetch_object()) {
                                if ($horsesCount > 0) {
                                    $per = ($cnt / $horsesCount) * 100;

                                    if ($per > $position_percentage) {
                                        // get rank
                                        $rank = $this->distanceNewRank(
                                            $handicap->minihandi,
                                            $numsArray
                                        );

                                        if ($rank) {
                                            $horseDetails = $this->db->horse_details($horseHist->horse_id);
                                            $this->logger->log($horseDetails->horse_name . " rank: $rank");
                                        }

                                        $updateQuery .=
                                            "UPDATE `tbl_hist_results` 
                                         SET `rank`='$rank' 
                                         WHERE `race_id`='$race->race_id' 
                                         AND `race_distance`= '$distance->racedist' 
                                         AND `horse_id`='$horseHist->horse_id';";
                                        $updateQueriesCount++;
                                    }
                                }
                            }
                            ++$i;
                        }
                    }
                }
                if ($updateQuery) {
                    $this->db->runMultipleQuery(
                        'tbl_hist_results',
                        $updateQuery,
                        $updateQueriesCount
                    );

                    $q = "UPDATE `tbl_races` 
                      SET `rank_status`='1' 
                      WHERE `race_id`='$race->race_id'";

                    if ($this->db->getDbConnection()->query($q)) {
                        $this->logger->log($q, 'debug');
                    } else {
                        $this->logger->log($this->db->getDbConnection()->error, 'error');
                    }
                }
            }
            $this->logger->log('Finish calculation of the Rank');
        } else {
            $this->logger->log('Rating: 0 results');
        }

        $this->logger->log('Finished: ' . __FUNCTION__);
    }

    /**
     * Update handicap
     *
     * @param string $offset Example: "0, 100", or "5", or just "0"
     * @param array $histIds Array of hist_results ids
     *
     * @return bool False in case of an error
     */
    function resetHandicap($offset = null, array $histIds = [])
    {
        $this->logger->log('Started: ' . __FUNCTION__);

        // Handicap Started
        if ($histIds) {
            $histIdStr = implode(', ', $histIds);
            $sql = "SELECT * FROM `tbl_hist_results` WHERE `hist_id` in ($histIdStr)";
        } elseif ($offset === null) {
            $sql = "UPDATE `tbl_hist_results` SET `handicap`='0'";
            $res = $this->db->getDbConnection()->query($sql);
            if (!$res) {
                $this->logger->log('MySQL error: ' . $this->db->getDbConnection()->error, 'error');
            }

            $sql = "SELECT * FROM `tbl_hist_results` WHERE `handicap`='0'";
        } else {
            $sql = "SELECT * FROM `tbl_hist_results` ORDER BY hist_id ASC LIMIT $offset";
        }
        $this->logger->log('Gather data for update: ' . $sql, 'debug');
        $resHandicap = $this->db->getDbConnection()->query($sql);

        if ($resHandicap->num_rows > 0) {
            $qHandicapHist = '';
            $qHandicapHistCount = '';
            while ($handicap = $resHandicap->fetch_object()) {
                $raceDetails = $this->db->race_details($handicap->race_id);
                $distance = round($raceDetails->race_distance / 100);
                $distance = $distance * 100;
                $newHandicap = $this->newvalue(
                    $handicap->length,
                    $raceDetails->race_distance,
                    $distance,
                    $handicap->horse_position,
                    number_format($handicap->race_time, 2)
                );
                $newHandicap = number_format($newHandicap, 3);

                $id = $handicap->hist_id;
                $qHandicapHist .= "UPDATE `tbl_hist_results` 
                               SET `handicap`='$newHandicap' 
                               WHERE hist_id = '$id';";
                $qHandicapHistCount++;

                if ($qHandicapHistCount >= 500) {
                    $this->db->runMultipleQuery(
                        'tbl_hist_results',
                        $qHandicapHist,
                        $qHandicapHistCount
                    );
                    $qHandicapHist = '';
                    $qHandicapHistCount = 0;
                }
            }
            if ($qHandicapHist) {
                $updated = $this->db->runMultipleQuery(
                    'tbl_hist_results',
                    $qHandicapHist,
                    $qHandicapHistCount
                );
                if (!$updated) {
                    return false;
                }
            }
        } else {
            $this->logger->log('No any data for update', 'debug');
        }
        $this->logger->log('Finished: ' . __FUNCTION__);

        return true;
    }

    /**
     * @param $race_id
     * @param $race_dist
     * @return int
     */
    public function get_handisum($race_id, $race_dist)
    {
        $get_hists = $this->db->getDbConnection()->query("SELECT MIN(handicap) AS minhandi FROM `tbl_hist_results` WHERE `race_id`='$race_id' AND `race_distance`='$race_dist' GROUP by horse_id");
        $totalhandi = 0;
        while ($gethand = $get_hists->fetch_object()) {
            $totalhandi += $gethand->minhandi;
        }

        return $totalhandi;
    }

    /**
     * @param $raceid
     * @param $racedis
     * @return array
     */
    public function get_array_of_handicap($raceid, $racedis)
    {
        $get_array = $this->db->getDbConnection()->query("SELECT DISTINCT `horse_id` FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis'");
        $arr = array();

        while ($arhorse = $get_array->fetch_object())
        {
            $get_histar = $this->db->getDbConnection()->query("SELECT MIN(handicap) as minihandi FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis' AND `horse_id`='$arhorse->horse_id'");
            while ($ahandi = $get_histar->fetch_object())
            {
                $arr[] = $ahandi->minihandi;
            }
        }

        return $arr;
    }

    /**
     * @param $race_id
     * @param $race_dist
     * @return int
     */
    public function get_sectionalsum($race_id, $race_dist)
    {
        $get_histsec = $this->db->getDbConnection()->query("SELECT MAX(avgsec) AS secavg FROM `tbl_hist_results` WHERE `race_id`='$race_id' AND `race_distance`='$race_dist' GROUP by horse_id");
        $totalsec = 0;
        while ($getsect = $get_histsec->fetch_object()) {
            $totalsec += $getsect->secavg;
        }

        return $totalsec;
    }

    /**
     * @param $raceid
     * @param $racedis
     * @return array
     */
    public function get_array_of_avgsec($raceid, $racedis)
    {
        $get_array = $this->db->getDbConnection()->query("SELECT DISTINCT `horse_id` FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis'");
        $arr = array();
        while ($arhorse = $get_array->fetch_object()) {
            $get_histar = $this->db->getDbConnection()->query("SELECT MAX(avgsec) AS secavg FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis' AND `horse_id`='$arhorse->horse_id'");
            while ($asec = $get_histar->fetch_object()) {
                $arr[] = $asec->secavg;
            }
        }

        return $arr;
    }

    /**
     * @param $length
     * @param $distance
     * @param $orgdistance
     * @param $pos
     * @param $time
     * @return float|int|mixed
     */
    public function newvalue($length, $distance, $orgdistance, $pos, $time)
    {
        //Getting the position of the horse
        $pos = explode('/', $pos);
        $position = intval($pos[0]);
        $modifier = MODIFIER;
        $remainder = $this->get_remainder($distance);

        if ($position == 1) {
            if ($distance < $orgdistance) {
                $newtime = $this->win_rounded_up(
                    $time,
                    $remainder
                );
            } else {
                $newtime = $this->win_rounded_down(
                    $time,
                    $remainder
                );
            }
        } else {
            if ($distance < $orgdistance) {
                $newtime = $this->loses_rounded_up(
                    $time,
                    $length,
                    $modifier,
                    $remainder
                );
            } else {
                if ($distance > $orgdistance) {
                    $newtime = $this->loses_rounded_down(
                        $time,
                        $length,
                        $modifier,
                        $remainder
                    );
                } else {
                    $newtime = $time + ($length * $modifier);
                }
            }
        }

        return $newtime;
    }

    /**
     * @param $distance
     * @return int
     */
    function get_remainder($distance)
    {
        if ($distance % 10 < 5) {
            $distance -= $distance % 10;
        } else {
            $distance += (10 - ($distance % 10));
        }

        if ($distance % 100 < 50) {
            $reminder_distance = $distance % 100;
        } else {
            $reminder_distance = (100 - ($distance % 100));
        }
        $reminder = $reminder_distance;

        return $reminder;
    }

    /**
     * @param $time
     * @param $remainder
     * @return float|int
     */
    public function win_rounded_up($time, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($this->timer * $remainder);
    }

    /**
     * @param $time
     * @param $remainder
     * @return float|int
     */
    public function win_rounded_down($time, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time - ($this->timer * $remainder);
    }


    /**
     * if horse loses
     * @param $time
     * @param $length
     * @param $modifier
     * @param $remainder
     * @return float|int
     */
    public function loses_rounded_up($time, $length, $modifier, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($length * $modifier) + ($this->timer * $remainder);
    }

    /**
     * @param $time
     * @param $length
     * @param $modifier
     * @param $remainder
     * @return float|int
     */
    public function loses_rounded_down($time, $length, $modifier, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($length * $modifier) - ($this->timer * $remainder);
    }

    /**
     * @param $handicap
     * @param $section
     * @param $oldweight
     * @param $newweight
     * @param $secpoint
     * @param int $h2h
     * @return float|int|mixed|string
     */
    public function rating_system($handicap, $section, $oldweight, $newweight, $secpoint, $h2h = 0)
    {
        if (strlen($section) > 0) {
            $pos = explode('/', $section);
        } else {
            $sectiontime = 0;
        }
        if (isset($pos[1])) {
            $sectiontime = $pos[1];
        } else {
            $sectiontime = 0;
        }

        // modify by Jfrost
        $h2hpoint = h2h_points($h2h);

        $weight = weight_points($oldweight, $newweight);
        $handicappoints = $handicap;
        // $handicappoints = $rankavg;
        //$sectionpoints = sectional avgvalue from  forumla;
        if ($sectiontime == 0) {
            $sectionpoints = 0;
        } else {
            $sectionpoints = ($secpoint / $sectiontime) * 100;
        }
        $sectionpoints = number_format($sectionpoints, 2);
        $rating = $handicappoints + $sectionpoints + ($weight / 100) + $h2hpoint;

        return $handicappoints . "+" . $sectionpoints . "+(" . $weight . "/100) = " . $rating;
    }


    function weight_points($oldweight, $newweight)
    {
        $weight = $newweight - $oldweight;
        $wgt = null;

        $weights = [
            ($weight > 3) => 1.5,
            ($weight > 2 && $weight <= 2.5) => 1,
            ($weight > 1 && $weight <= 1.5) => 0.5,
            ($weight > 0 && $weight <= 0.5) => 1,
            ($weight > -0.5 && $weight <= 0) => -1.5,
            ($weight > -1 && $weight <= -1.5) => -2,
            ($weight > -1 && $weight <= -2.5) => -2,
            ($weight > -3 && $weight < -2.5) => -3
        ];

        foreach ($weights as $w => $value) {
            if ($w) {
                $wgt = $value;
            }
        }

        return $wgt;
    }


    public function h2h_points($h2h)
    {
        $h2hpoint = null;
        if (isset(explode("-", $h2h)[1])) {
            $h2h_ = intval(explode("-", $h2h)[0]) - intval(explode("-", $h2h)[1]);
        } else {
            $h2h_ = 0;
        }
        $h2hpoint = number_format($h2h_ / 2, 1);
        return $h2hpoint;
    }

    /**
     * @param $value
     * @param $array
     * @param int $order
     * @return float|int|null
     */
    public function generate_rank($value, $array, $order = 0)
    {
        // sort
        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        // add item for counting from 1 but 0
        array_unshift($array, $value + 1);

        // select all indexes with the value
        $keys = array_keys($array, $value);
        if (count($keys) == 0) {
            return null;
        }

        // calculate the rank
        $res = array_sum($keys) / count($keys);

        return $res / 2;
    }

    function generate_avgsectional($value, $array, $order = 0)
    {
        // sort
        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        // add item for counting from 1 but 0
        array_unshift($array, $value + 1);

        // select all indexes with the value
        $keys = array_keys($array, $value);
        if (count($keys) == 0) {
            return null;
        }

        // calculate the rank
        $res = array_sum($keys) / count($keys);

        return $res / 2;
    }

    function rating_system_new($rankavg, $avgsectional)
    {
        $rating = $rankavg + $avgsectional;

        return $rating;
    }

    function distanceRank($value, $array, $order = 0)
    {
        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        array_unshift($array, $value + 1);
        $keys = array_keys($array, $value);

        if (count($keys) == 0) {
            return null;
        }

        return count($keys);
    }

    public function distanceNewRank($value, $array, $order = 0)
    {
        $array = array_unique($array);

        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        return array_search($value, $array) + 1;
    }

    /**
     * Reset rankings: rank, rating, sectional, avgsectional, avgsec
     *
     * @param bool $rank
     * @param bool $rating
     * @param bool $sectional
     * @param bool $avgSectional
     * @param bool $avgSec
     *
     * @return bool False in a case if something went wrong
     */
    public function resetRankings(
        $rank = true,
        $rating = true,
        $sectional = true,
        $avgSectional = true,
        $avgSec = true
    )
    {
        $query = "UPDATE tbl_hist_results SET ";
        $expressions = [
            ((bool)$rank) ? 'rank = 0, ' : '',
            ((bool)$rating) ? 'rating = 0, ' : '',
            ((bool)$avgSectional) ? 'avgsectional = 0, ' : '',
            ((bool)$avgSec) ? 'avgsec = 0, ' : '',
            ((bool)$sectional) ? 'sectional = 0, ' : '',
        ];

        foreach ($expressions as $exp) {
            $query .= $exp;
        }

        $query = substr($query, 0, -2);
        $res = $this->db->getDbConnection()->query($query);
        if (!$res) {
            if ($this->logger !== null) $this->logger->log(
                'Error on reset ranking: ' . $this->db->getDbConnection()->error);
            return false;
        }

        return true;
    }
}