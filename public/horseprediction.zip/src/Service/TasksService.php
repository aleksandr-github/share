<?php

namespace App\Service;

use Amp\Loop;
use Amp\Parallel\Worker\DefaultPool;
use App\DataTransformer\HorsesForRacesTransformer;
use App\DataTransformer\RacesForMeetingsTransformer;
use App\Helper\ArrayObjectHelper;
use App\Task\GetHorsesForRacesTask;
use App\Task\GetRacesForMeetingsTask;
use App\Task\GetRecordsForHorsesInRacesTask;
use App\Task\ResetHandicapForHistoricResultTask;
use App\Task\SaveHorsesTask;
use App\Task\SaveMeetingsTask;
use App\Task\SaveRacesTask;
use App\Task\SaveRecordsTask;
use App\Task\UpdateDistanceForRaceTask;
use App\Task\UpdateHandicapForRaceTask;
use Doctrine\Common\Collections\ArrayCollection;
use Throwable;
use function Amp\call as callAmp;
use function Amp\Promise\all as waitAll;
use function Amp\Promise\first as firstPromise;

class TasksService
{
    protected $logger;

    // TODO move it to env probably
    protected $workersNumber = 12;

    protected $dbConnector;

    public function __construct()
    {
        $this->logger = new PrettyLogger(__FILE__, "main_log.txt");
        $this->dbConnector = new DBConnector();
    }

    /**
     * @param ArrayCollection $horses
     * @return mixed
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function saveHorses(ArrayCollection $horses)
    {
        $results = [];
        $tasks = [];

        // build tasks
        foreach ($horses->toArray() as $raceIdKey => $raceArrayCollection) {
            foreach ($raceArrayCollection->toArray() as $horse) {
                $task = new SaveHorsesTask($horse);
                $uniqueId = $horse["field_id"] . $horse["id"] . random_int(0, 99999);
                $tasks[$uniqueId] = $task;
            }
        }

        $this->runTasks($tasks, $results);

        return $results;
    }

    /**
     * @param ArrayCollection $meetingsForDateRange
     * @return mixed
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function saveMeetings(ArrayCollection $meetingsForDateRange)
    {
        $results = [];
        $tasks = [];

        // build tasks
        foreach ($meetingsForDateRange->toArray() as $meeting) {
            $task = new SaveMeetingsTask($meeting);
            $tasks[$meeting["url"]] = $task;
        }

        $this->runTasks($tasks, $results);

        return $results;
    }

    /**
     * @param array $meetings
     * @return ArrayCollection
     * @throws Throwable
     *
     * @uses \Amp\Http\Client\HttpClientBuilder
     */
    public function getRacesForMeetings(array $meetings): ArrayCollection
    {
        $results = [];
        $tasks = [];

        // build tasks
        foreach ($meetings as $meeting) {
            $task = new GetRacesForMeetingsTask($meeting);
            $tasks[$meeting["meeting_url"]] = $task;
        }

        $this->runTasks($tasks, $results);

        return (new RacesForMeetingsTransformer($results))->transform();
    }


    /**
     * @param ArrayCollection $races
     * @return mixed
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function saveRaces(ArrayCollection $races)
    {
        $results = [];
        $tasks = [];

        // build tasks
        foreach ($races->toArray() as $race) {
            $task = new SaveRacesTask($race);
            $tasks[$race["url"]] = $task;
        }

        $this->runTasks($tasks, $results);

        return $results;
    }

    /**
     * @param array $meetings
     * @return ArrayCollection
     * @throws Throwable
     *
     * @uses \Amp\Http\Client\HttpClientBuilder
     */
    public function getHorsesForRaces(array $races): ArrayCollection
    {
        $results = [];
        $tasks = [];

        // build tasks
        foreach ($races as $race) {
            $task = new GetHorsesForRacesTask($race);
            $tasks[$race["race_url"]] = $task;
        }

        $this->runTasks($tasks, $results);

        return (new HorsesForRacesTransformer($results))->transform();
    }

    /**
     * @param ArrayCollection $horsesInRacesArrayCollection
     * @param bool $chunked
     * @return array
     *
     * @uses \Amp\Http\Client\HttpClientBuilder
     */
    public function getRecordsForHorsesInRaces(ArrayCollection $horsesInRacesArrayCollection, bool $chunked = true): array
    {
        $results = [];
        $tasks = [];

        // chunked is somewhat faster but requires testing
        if ($chunked) {
            $resultingPromiseArray = [];
            $workersLimit = 1;
            $splicedHorsesInRacesArray = array_chunk($horsesInRacesArrayCollection->toArray(), $workersLimit, true);
            foreach ($splicedHorsesInRacesArray as $chunkKey => $item) {
                $horseRaceResults = [];
                $timeNow = microtime(true);
                $this->logger->log("Starting chunk " . $chunkKey . " out of " . count($splicedHorsesInRacesArray) . " in records... ");
                foreach ($item as $raceKeyId => $horseRaceResults) {
                    foreach ($horseRaceResults as $horseRaceResult) {
                        $task = new GetRecordsForHorsesInRacesTask($horseRaceResult, $raceKeyId);
                        $tasks[$horseRaceResult["race_id"] . $horseRaceResult["id"]] = $task;
                    }
                }

                $this->runTasks($tasks, $results);

                $resultingPromiseArray[] = $results;

                $timeDiff = microtime(true) - $timeNow;
                $this->logger->log("Chunk " . $chunkKey . " containing " . count($horseRaceResults) ." entries finished in " . number_format($timeDiff, 2) . " seconds.");
            }

            // hard coded transformer TODO resolve to Transformer class
            $promisesFinal = [];
            foreach ($resultingPromiseArray as $item) {
                foreach ($item as $promiseFinal) {
                    $promisesFinal[] = $promiseFinal;
                }
            }

            return $promisesFinal;
        } else {
            foreach ($horsesInRacesArrayCollection->toArray() as $raceKeyId => $horseRaceResults) {
                foreach ($horseRaceResults as $horseRaceResult) {
                    $task = new GetRecordsForHorsesInRacesTask($horseRaceResult, $raceKeyId);
                    $tasks[$horseRaceResult["race_id"] . $horseRaceResult["id"]] = $task;
                }
            }

            $this->runTasks($tasks, $results);

            return $results;
        }
    }


    /**
     * @param ArrayCollection $races
     * @return mixed
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function saveRecords($records)
    {
        $results = [];
        $tasks = [];

        foreach ($records as $recordsForHorseArray) {
            foreach ($recordsForHorseArray as $recordsArray) {
                if (count($recordsArray) > 0) {
                    foreach ($recordsArray as $record) {
                        $task = new SaveRecordsTask($record);
                        $tasks[] = $task;
                    }
                }
            }
        }

        $this->runTasks($tasks, $results, 32);

        return $this->dbConnector->multiQueryInsertIDs(implode("", $results));
    }

    /**
     * @param array $histResults
     * @return bool
     *
     * @uses \mysqli
     */
    public function resetHandicapForHistoricResults(array $histResults): bool
    {
        $results = [];
        $tasks = [];

        foreach ($histResults as $histResult) {
            $histResultObject = ArrayObjectHelper::covertToObject($histResult);
            $task = new ResetHandicapForHistoricResultTask($histResultObject);
            $tasks[] = $task;
        }

        $this->runTasks($tasks, $results); // test more workers

        return true;
    }

    /**
     * @param array $races
     * @return bool
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function updateHandicapTimeForRaces(array $races): bool
    {
        $results = [];
        $tasks = [];

        foreach ($races as $race) {
            $raceObject = ArrayObjectHelper::covertToObject($race);
            $task = new UpdateHandicapForRaceTask($raceObject);
            $tasks[] = $task;
        }

        $this->runTasks($tasks, $results); // test more workers

        return true;
    }

    /**
     * @param array $races
     * @param array $raceDistanceArray
     * @return bool
     * @throws Throwable
     *
     * @uses \mysqli
     */
    public function updateDistanceForRaces(array $races, array $raceDistanceArray): bool
    {
        $results = [];
        $tasks = [];

        foreach ($races as $race) {
            $raceObject = ArrayObjectHelper::covertToObject($race);
            $task = new UpdateDistanceForRaceTask($raceObject, $raceDistanceArray[$raceObject->race_id]);
            $tasks[] = $task;
        }

        $this->runTasks($tasks, $results); // test more workers

        return true;
    }

    /**
     * @param array $tasks
     * @param array $results
     * @param null $workersNumber
     */
    protected function runTasks(array $tasks, array &$results, $workersNumber = null)
    {
        if ($workersNumber == null) {
            $workersNumber = $this->workersNumber;
        }

        Loop::run(function () use (&$results, $tasks, $workersNumber) {
            $allCoroutines = [];
            $loopRoutines = [];
            $pool = new DefaultPool($workersNumber);
            foreach ($tasks as $index => $task) {
                $coroutine = callAmp(function () use ($pool, $task) {
                    return yield $pool->enqueue($task);
                });
                $loopRoutines[] = $coroutine;
                $allCoroutines[] = $coroutine;
                if ($pool->getWorkerCount() >= $workersNumber && $pool->getIdleWorkerCount() === 0) {
                    yield firstPromise($loopRoutines);
                    $loopRoutines = [];
                }
            }
            $results = yield waitAll($allCoroutines);

            return yield $pool->shutdown();
        });
    }

}
