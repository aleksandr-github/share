<?php

namespace App\Task;

use Amp\Parallel\Worker\Environment;
use Amp\Parallel\Worker\Task;
use App\Service\PrettyLogger;
use Exception;
use mysqli;
use stdClass;
use Symfony\Component\Dotenv\Dotenv;

class ResetHandicapForHistoricResultTask implements Task
{
    /**
     * @var object
     *
     * historic_result (tbl_hist_results)
    (
    [hist_id] => 1
    [race_id] => 1
    [race_date] => 2020-09-20
    [race_distance] => 1200
    [horse_id] => 12
    [h_num] => 2
    [horse_position] => 5
    [horse_weight] => 56.0
    [horse_fixed_odds] => $6.5
    [horse_h2h] => 1-1
    [temp_h2h] =>
    [prize] => 1k/35k
    [race_time] => 1.23
    [length] => 5.8
    [sectional] => 600/36.11
    [avgsec] => 0
    [avgsectional] => 0
    [handicap] => 0
    [rating] => 0
    [rank] => 0
    )

     */
    protected $data;

    /**
     * @var PrettyLogger
     */
    protected $logger;

    protected $timer = 0.07;
    protected $modifier = 0.025;

    public function __construct(object $histResult)
    {
        $this->data = $histResult;
        $this->logger = new PrettyLogger(__FILE__, 'main_log.txt');
    }

    /**
     * @param Environment $environment
     * @throws Exception
     */
    public function run(Environment $environment)
    {
        $algStart = microtime(true);
        $mysqli = $this->initMultiSessionDatabase();

        $this->logger->log("(╯°□°）╯ ︵ ┻━┻ Starting worker for: " . $this->data->hist_id . '@' . $this->data->race_id . '#' . $this->data->horse_id);

        // TODO probably fails here
        $raceDetails = $this->getRace($this->data->race_id, $mysqli);
        $distance = round($raceDetails->race_distance / 100);
        $distance = $distance * 100;
        $newHandicap = $this->getNewValueForTimeDistance(
            $this->data->length,
            $raceDetails->race_distance,
            $distance,
            $this->data->horse_position,
            number_format($this->data->race_time, 2)
        );
        $newHandicap = number_format($newHandicap, 3);

        $id = $this->data->hist_id;
        $sql = "UPDATE `tbl_hist_results` SET `handicap`='$newHandicap' WHERE hist_id = '$id';";
        $stmt = $mysqli->query($sql);
        if (!$stmt) {
            $msg = "Query failed: (" . $mysqli->errno . ") " . $mysqli->error;
            $this->logger->log($msg);

            throw new Exception($msg);
        }

        $time_elapsed_secs = microtime(true) - $algStart;
        $this->logger->log("┏━┓ ︵  /(^.^/) Worker for: " . $this->data->hist_id . '@' . $this->data->race_id . '#' . $this->data->horse_id . " finished in " . number_format($time_elapsed_secs, 2) . ' seconds');

        return $mysqli->insert_id;
    }

    /**
     * @return mysqli
     */
    protected function initMultiSessionDatabase(): mysqli
    {
        (new Dotenv())->bootEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '.env');

        $mysqli = new mysqli(
            $_ENV["dbservername"],
            $_ENV["dbusername"],
            $_ENV["dbpassword"],
            $_ENV["dbdatabase"]
        );
        $mysqli->ping();

        return $mysqli;
    }

    /**
     * @param $length
     * @param $distance
     * @param $orgdistance
     * @param $pos
     * @param $time
     * @return float|int|mixed
     */
    protected function getNewValueForTimeDistance($length, $distance, $orgdistance, $pos, $time)
    {
        //Getting the position of the horse
        $pos = explode('/', $pos);
        $position = intval($pos[0]);
        $modifier = $this->modifier;
        $remainder = $this->getRemainingDistance($distance);

        if ($position == 1) {
            if ($distance < $orgdistance) {
                $newtime = $this->roundWinUp($time, $remainder);
            } else {
                $newtime = $this->roundWinDown($time, $remainder);
            }
        } else {
            if ($distance < $orgdistance) {
                $newtime = $this->roundLoseUp(
                    $time,
                    $length,
                    $modifier,
                    $remainder
                );
            } else {
                if ($distance > $orgdistance) {
                    $newtime = $this->roundLoseDown(
                        $time,
                        $length,
                        $modifier,
                        $remainder
                    );
                } else {
                    $newtime = $time + ($length * $modifier);
                }
            }
        }

        return $newtime;
    }

    /**
     * @param $raceId
     * @param $mysqli
     * @return object|stdClass
     */
    public function getRace($raceId, $mysqli)
    {
        $stmt = $mysqli->query("SELECT * FROM `tbl_races` WHERE `race_id`='$raceId'");
        $raceDetails = $stmt->fetch_object();

        return $raceDetails;
    }

    /**
     * @param $distance
     * @return int
     */
    protected function getRemainingDistance($distance): int
    {
        if ($distance % 10 < 5) {
            $distance -= $distance % 10;
        } else {
            $distance += (10 - ($distance % 10));
        }

        if ($distance % 100 < 50) {
            $reminder_distance = $distance % 100;
        } else {
            $reminder_distance = (100 - ($distance % 100));
        }

        return $reminder_distance;
    }

    /**
     * @param $time
     * @param $remainder
     * @return float|int
     */
    protected function roundWinUp($time, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($this->timer * $remainder);
    }

    /**
     * @param $time
     * @param $remainder
     * @return float|int
     */
    protected function roundWinDown($time, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time - ($this->timer * $remainder);
    }

    /**
     * if horse loses
     * @param $time
     * @param $length
     * @param $modifier
     * @param $remainder
     * @return float|int
     */
    protected function roundLoseUp($time, $length, $modifier, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($length * $modifier) + ($this->timer * $remainder);
    }

    /**
     * @param $time
     * @param $length
     * @param $modifier
     * @param $remainder
     * @return float|int
     */
    protected function roundLoseDown($time, $length, $modifier, $remainder)
    {
        if ($this->timer === null) {
            $this->logger->log(__FUNCTION__ . ': $this->timer variable was not imported. The result will be calculated wrong', 'error');
        }
        return $time + ($length * $modifier) - ($this->timer * $remainder);
    }
}