<?php

namespace App\Task;

use Amp\Parallel\Worker\Environment;
use Amp\Parallel\Worker\Task;
use App\Service\PrettyLogger;
use Exception;
use mysqli;
use Symfony\Component\Dotenv\Dotenv;

class SaveHorsesTask implements Task
{
    /**
     * @var array
     */
    protected $data;

    /**
     * @var PrettyLogger
     */
    protected $logger;

    protected $base_url = "https://www.racingzone.com.au";

    public function __construct(array $meeting)
    {
        $this->data = $meeting;
        $this->logger = new PrettyLogger(__FILE__, 'main_log.txt');
    }

    /**
     * @param Environment $environment
     * @return int|mixed|string
     * @throws Exception
     */
    public function run(Environment $environment)
    {
        $algStart = microtime(true);
        $mysqli = $this->initMultiSessionDatabase();

        $this->logger->log("(╯°□°）╯ ︵ ┻━┻ Starting worker for: " . $this->data["name"] . "@" . $this->data["field_id"]);

        $horse_id = 0;
        $hslug = preg_replace('/[^A-Za-z0-9\-]/', '', strtolower($this->data["horse_name"]));
        $today_date = date("Y-m-d H:i:s");
        $stmt = $mysqli->prepare("SELECT horse_id FROM tbl_horses WHERE horse_slug = ? LIMIT 1");
        $stmt->bind_param("s", $hslug);
        if ($stmt->execute()) {
            $stmt->bind_result($horse_id);
            while ($stmt->fetch()) {
                $horse_id = $horse_id;
            }
            $stmt->close();
        } else {
            $msg = "[" . date("Y-m-d H:i:s") . "] Select horse_id failed";
            $this->logger->log($msg);
        }

        if ($horse_id) {
            $action_now = 'updated';

            //adding temp races
            $stathra = $mysqli->prepare("INSERT INTO `tbl_temp_hraces` (`race_id`, `horse_id`, `horse_num`, `horse_fxodds`, `horse_h2h`, `horse_weight`, `horse_win`, `horse_plc`, `horse_avg`) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? );");
            $stathra->bind_param("sssssssss", $this->data["race_id"], $horse_id, $this->data["horse_number"], $this->data["horse_fixed_odds"], $this->data["horse_h2h"], $this->data["horse_weight"], $this->data["horse_win"], $this->data["horse_plc"], $this->data["horse_avg"]);
            $stathra->execute();
            $stathra->close();
            // end temp races
        }

        $sql = "INSERT INTO `tbl_horses` (`horse_name`, `horse_slug`, `horse_latest_results`, `added_on` ) VALUES ( ?, ?, ?, ? );";

        if (!($stmt_horses = $mysqli->prepare($sql))) {
            $msg = "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
            $this->logger->log($msg);
            throw new \Exception($msg);
        }
        $mysqliStatement = $stmt_horses;

        $mysqliStatement->bind_param("ssss", $this->data["horse_name"], $hslug, $this->data["horse_latest_results"], $today_date);
        if (!$mysqliStatement->execute()) {
            $msg = "[" . date("Y-m-d H:i:s") . "] Insert failed: " . $mysqliStatement->error;
            $this->logger->log($msg);
        }

        $horseInsertId = $mysqli->insert_id;
        if ($horseInsertId) {
            $horse_id_n = $mysqli->insert_id;
            $action_now = 'added';
            if(empty($this->data["horse_fixed_odds"])) {
                $horse_fixed_odds = '0';
            }
            else {
                $horse_fixed_odds = $this->data["horse_fixed_odds"];
            }

            if(empty($this->data["horse_h2h"])) {
                $horse_h2hnow = '0';
            }
            else {
                $horse_h2hnow = $this->data["horse_h2h"];
            }

            if(empty($this->data["horse_number"])) {
                $horse_cnumber = '0';
            }
            else {
                $horse_cnumber = $this->data["horse_number"];
            }

            //adding temp races
            $stathra = $mysqli->prepare("INSERT INTO `tbl_temp_hraces` (`race_id`, `horse_id`, `horse_num`, `horse_fxodds`, `horse_h2h`, `horse_weight`, `horse_win`, `horse_plc`, `horse_avg` ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? );");
            $stathra->bind_param("sssssssss", $this->data["race_id"], $horse_id_n, $this->data["horse_number"], $horse_fixed_odds, $horse_h2hnow, $this->data["horse_weight"], $this->data["horse_win"], $this->data["horse_plc"], $this->data["horse_avg"]);
            $stathra->execute();
            $stathra->close();
            // end temp races
        }
        
        $time_elapsed_secs = microtime(true) - $algStart;
        $this->logger->log("┏━┓ ︵  /(^.^/) Worker for: " . $this->data["name"] . "@" . $this->data["field_id"] . " finished in " . number_format($time_elapsed_secs, 2) . ' seconds');

        return $horseInsertId;
    }

    /**
     * @return mysqli
     */
    protected function initMultiSessionDatabase(): mysqli
    {
        (new Dotenv())->bootEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '.env');

        $mysqli = new mysqli(
            $_ENV["dbservername"],
            $_ENV["dbusername"],
            $_ENV["dbpassword"],
            $_ENV["dbdatabase"]
        );
        $mysqli->ping();

        return $mysqli;
    }
}