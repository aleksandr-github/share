<?php

namespace App\Task;

use Amp\Parallel\Worker\Environment;
use Amp\Parallel\Worker\Task;
use App\Service\PrettyLogger;
use Exception;
use mysqli;
use Symfony\Component\Dotenv\Dotenv;

class UpdateDistanceForRaceTask implements Task
{
    /**
     * @var object
     */
    protected $data;

    /**
     * @var PrettyLogger
     */
    protected $logger;

    protected $base_url = "https://www.racingzone.com.au";

    protected $positionPercentage = 40;

    protected $raceDistance;

    public function __construct(object $race, $raceDistance)
    {
        $this->data = $race;
        $this->raceDistance = $raceDistance;
        $this->logger = new PrettyLogger(__FILE__, 'main_log.txt');
    }

    /**
     * @param Environment $environment
     * @return bool
     * @throws Exception
     */
    public function run(Environment $environment): bool
    {
        $algStart = microtime(true);
        $mysqli = $this->initMultiSessionDatabase();

        $this->logger->log("(╯°□°）╯ ︵ ┻━┻ Starting worker for: " . $this->data->race_id);

        $horsesCount = $mysqli->query("SELECT * FROM `tbl_temp_hraces` WHERE `race_id`='".$this->data->race_id."' AND `horse_fxodds`!='0'")->num_rows;
        $distancesResult = $mysqli->query(
            "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                 FROM tbl_hist_results 
                 WHERE `race_id`=".$this->data->race_id." 
                 AND `race_distance`='".$this->raceDistance."' 
                 ORDER by racedist ASC"
        );

        while ($distance = $distancesResult->fetch_object()) {
            $numsArray = $this->getArrayOfHandicap($this->data->race_id, $distance->racedist, $mysqli);
            $cnt = count($numsArray);
            $horsesHistResult = $mysqli->query(
                "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`=".$this->data->race_id." 
                     AND `race_distance`='$distance->racedist'"
            );

            while ($horseHist = $horsesHistResult->fetch_object()) {
                $odds = $mysqli->query(
                    "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`=".$this->data->race_id." 
                         AND `horse_id`='".$horseHist->horse_id."'"
                );
                $oddsResult = $odds->fetch_object();

                if (isset($oddsResult->horse_fxodds)
                    && $oddsResult->horse_fxodds != "0") {
                    $handicapResult = $mysqli->query(
                        "SELECT MIN(handicap) as minihandi 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`=".$this->data->race_id." 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horseHist->horse_id'"
                    );

                    while ($handicap = $handicapResult->fetch_object()) {
                        if ($horsesCount > 0) {
                            $per = ($cnt / $horsesCount) * 100;

                            if ($per > $this->positionPercentage) {
                                // get rank
                                $rank = $this->distanceNewRank(
                                    $handicap->minihandi,
                                    $numsArray
                                );

                                $updateQuery =
                                    "UPDATE `tbl_hist_results` 
                                         SET `rank`='$rank' 
                                         WHERE `race_id`=".$this->data->race_id." 
                                         AND `race_distance`= '$distance->racedist' 
                                         AND `horse_id`='$horseHist->horse_id';";
                                $mysqli->query($updateQuery);

                                $q = "UPDATE `tbl_races` 
                                          SET `rank_status`='1' 
                                          WHERE `race_id`=".$this->data->race_id;
                                $mysqli->query($q);
                            }
                        }
                    }
                }
            }
        }

        $time_elapsed_secs = microtime(true) - $algStart;
        $this->logger->log("┏━┓ ︵  /(^.^/) Worker for: " . $this->data->race_id . " finished in " . number_format($time_elapsed_secs, 2) . ' seconds');

        return true;
    }

    /**
     * @return mysqli
     */
    protected function initMultiSessionDatabase(): mysqli
    {
        (new Dotenv())->bootEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '.env');

        $mysqli = new mysqli(
            $_ENV["dbservername"],
            $_ENV["dbusername"],
            $_ENV["dbpassword"],
            $_ENV["dbdatabase"]
        );
        $mysqli->ping();

        return $mysqli;
    }

    /**
     * @param $raceid
     * @param $racedis
     * @param $mysqli
     * @return array
     */
    protected function getArrayOfHandicap($raceid, $racedis, $mysqli): array
    {
        $get_array = $mysqli->query("SELECT DISTINCT `horse_id` FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis'");
        $arr = array();

        while ($arhorse = $get_array->fetch_object())
        {
            $get_histar = $mysqli->query("SELECT MIN(handicap) as minihandi FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis' AND `horse_id`='$arhorse->horse_id'");
            while ($ahandi = $get_histar->fetch_object())
            {
                $arr[] = $ahandi->minihandi;
            }
        }

        return $arr;
    }

    /**
     * @param $value
     * @param $array
     * @param int $order
     * @return false|int|string
     */
    protected function distanceNewRank($value, $array, $order = 0)
    {
        $array = array_unique($array);

        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        return array_search($value, $array) + 1;
    }
}