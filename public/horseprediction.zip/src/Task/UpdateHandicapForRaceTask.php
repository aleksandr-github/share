<?php

namespace App\Task;

use Amp\Parallel\Worker\Environment;
use Amp\Parallel\Worker\Task;
use App\Service\PrettyLogger;
use Exception;
use mysqli;
use Symfony\Component\Dotenv\Dotenv;

class UpdateHandicapForRaceTask implements Task
{
    /**
     * @var object
     */
    protected $data;

    /**
     * @var PrettyLogger
     */
    protected $logger;

    protected $positionPercentage = 40;

    public function __construct(object $race)
    {
        $this->data = $race;
        $this->logger = new PrettyLogger(__FILE__, 'main_log.txt');
    }

    public function run(Environment $environment): bool
    {
        $algStart = microtime(true);
        $mysqli = $this->initMultiSessionDatabase();

        $this->logger->log("(╯°□°）╯ ︵ ┻━┻ Starting worker for: " . $this->data->race_id);

        /** UPDATE RANK SECTION */
        $this->updateRankSectionForRace($this->data, $mysqli);
        /** UPDATE SECTIONAL AVG */
        $this->updateSectionalAVGForRace($this->data, $mysqli);
        /** UPDATE RATING */
        try {
            $this->updateRatingsForRace($this->data, $mysqli);
        } catch (Exception $e) {
            $this->logger->log("Ratings for race " . $this->data->race_id . " not done. Cause: " . $e->getMessage());
        }

        $time_elapsed_secs = microtime(true) - $algStart;
        $this->logger->log("┏━┓ ︵  /(^.^/) Worker for: " . $this->data->race_id . " finished in " . number_format($time_elapsed_secs, 2) . ' seconds');

        return true;
    }

    /**
     * @return mysqli
     */
    protected function initMultiSessionDatabase(): mysqli
    {
        (new Dotenv())->bootEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '.env');

        $mysqli = new mysqli(
            $_ENV["dbservername"],
            $_ENV["dbusername"],
            $_ENV["dbpassword"],
            $_ENV["dbdatabase"]
        );
        $mysqli->ping();

        return $mysqli;
    }

    private function updateRankSectionForRace(object $race, mysqli $mysqli)
    {
        $horsesCount = $mysqli->query("SELECT * FROM `tbl_temp_hraces` WHERE `race_id`='".$this->data->race_id."' AND `horse_fxodds`!='0'")->num_rows;

        $qDistance = "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                          FROM tbl_hist_results 
                          WHERE `race_id`='$race->race_id' 
                          ORDER by racedist ASC";
        $distances = $mysqli->query($qDistance);

        while ($distance = $distances->fetch_object()) {
            $numsArray = $this->getArrayOfHandicap(
                $race->race_id,
                $distance->racedist,
                $mysqli
            );
            $cnt = count($numsArray);

            $horsesHistResult = $mysqli->query(
                "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`='$race->race_id' 
                     AND `race_distance`='$distance->racedist'"
            );

            while ($horse = $horsesHistResult->fetch_object()) {
                $oddsResult = $mysqli->query(
                    "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`='$race->race_id' 
                         AND `horse_id`='$horse->horse_id'"
                );

                if ($oddsResult->num_rows === 0) continue;
                $odds = $oddsResult->fetch_object();

                if (isset($odds->horse_fxodds)
                    && $odds->horse_fxodds != "0"
                ) {
                    $handicapResults = $mysqli->query(
                        "SELECT MIN(handicap) as minihandi 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`='$race->race_id' 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horse->horse_id'"
                    );

                    while ($row = $handicapResults->fetch_object()) {
                        if ($horsesCount > 0) {
                            $per = ($cnt / $horsesCount) * 100;

                            if ($per > $this->positionPercentage) {
                                $rank = $this->generateRank(
                                    $row->minihandi,
                                    $numsArray
                                );

                                $q = "UPDATE `tbl_hist_results` 
                                        SET `rank`='$rank' 
                                        WHERE `race_id`='$race->race_id' 
                                        AND `race_distance`= '$distance->racedist' 
                                        AND `horse_id`='$horse->horse_id';";
                                $mysqli->query($q);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $raceid
     * @param $racedis
     * @param $mysqli
     * @return array
     */
    protected function getArrayOfHandicap($raceid, $racedis, $mysqli): array
    {
        $get_array = $mysqli->query("SELECT DISTINCT `horse_id` FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis'");
        $arr = array();

        while ($arhorse = $get_array->fetch_object())
        {
            $get_histar = $mysqli->query("SELECT MIN(handicap) as minihandi FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis' AND `horse_id`='$arhorse->horse_id'");
            while ($ahandi = $get_histar->fetch_object())
            {
                $arr[] = $ahandi->minihandi;
            }
        }

        return $arr;
    }

    /**
     * @param $value
     * @param $array
     * @param int $order
     * @return float|int|null
     */
    protected function generateRank($value, $array, $order = 0)
    {
        // sort
        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        // add item for counting from 1 but 0
        array_unshift($array, $value + 1);

        // select all indexes with the value
        $keys = array_keys($array, $value);
        if (count($keys) == 0) {
            return null;
        }

        // calculate the rank
        $res = array_sum($keys) / count($keys);

        return $res / 2;
    }

    private function updateSectionalAVGForRace(object $race, mysqli $mysqli)
    {
        $horsesCount = $mysqli->query("SELECT * FROM `tbl_temp_hraces` WHERE `race_id`='".$this->data->race_id."' AND `horse_fxodds`!='0'")->num_rows;

        $qDistance = "SELECT DISTINCT CAST(race_distance AS UNSIGNED) AS racedist 
                          FROM tbl_hist_results 
                          WHERE `race_id`='$race->race_id' 
                          ORDER by racedist ASC";
        $distances = $mysqli->query($qDistance);

        while ($distance = $distances->fetch_object()) {
            $numsArray = $this->getArrayOfAVGSectional($race->race_id, $distance->racedist, $mysqli);
            $cnt = count($numsArray);

            $horsesHistResult = $mysqli->query(
                "SELECT DISTINCT `horse_id` 
                     FROM `tbl_hist_results` 
                     WHERE `race_id`='$race->race_id' 
                     AND `race_distance`='$distance->racedist'"
            );

            while ($horse = $horsesHistResult->fetch_object()) {
                $oddsResult = $mysqli->query(
                    "SELECT * FROM `tbl_temp_hraces` 
                         WHERE `race_id`='$race->race_id' 
                         AND `horse_id`='$horse->horse_id'"
                );
                if ($oddsResult->num_rows === 0) continue;

                $odds = $oddsResult->fetch_object();
                if ($odds->horse_fxodds != "0") {
                    $handicapResults = $mysqli->query(
                        "SELECT MAX(avgsec) AS secavg 
                             FROM `tbl_hist_results` 
                             WHERE `race_id`='$race->race_id' 
                             AND `race_distance`='$distance->racedist' 
                             AND `horse_id`='$horse->horse_id'"
                    );

                    while ($row = $handicapResults->fetch_object()) {
                        $per = ($cnt / $horsesCount) * 100;

                        if ($per > $this->positionPercentage) {
                            $avgSectional = $this->generateAVGSectional(
                                $row->secavg,
                                $numsArray
                            );
                            $q = "UPDATE `tbl_hist_results` 
                                     SET `avgsectional`='$avgSectional' 
                                     WHERE `race_id`='$race->race_id' 
                                     AND `race_distance`= '$distance->racedist' 
                                     AND `horse_id`='$horse->horse_id';";
                            $mysqli->query($q);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $raceid
     * @param $racedis
     * @param $mysqli
     * @return array
     */
    protected function getArrayOfAVGSectional($raceid, $racedis, $mysqli): array
    {
        $get_array = $mysqli->query("SELECT DISTINCT `horse_id` FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis'");
        $arr = array();
        while ($arhorse = $get_array->fetch_object()) {
            $get_histar = $mysqli->query("SELECT MAX(avgsec) AS secavg FROM `tbl_hist_results` WHERE `race_id`='$raceid' AND `race_distance`='$racedis' AND `horse_id`='$arhorse->horse_id'");
            while ($asec = $get_histar->fetch_object()) {
                $arr[] = $asec->secavg;
            }
        }

        return $arr;
    }

    /**
     * @param $value
     * @param $array
     * @param int $order
     * @return float|int|null
     */
    protected function generateAVGSectional($value, $array, $order = 0)
    {
        // sort
        if ($order) {
            sort($array);
        } else {
            rsort($array);
        }

        // add item for counting from 1 but 0
        array_unshift($array, $value + 1);

        // select all indexes with the value
        $keys = array_keys($array, $value);
        if (count($keys) == 0) {
            return null;
        }

        // calculate the rank
        $res = array_sum($keys) / count($keys);

        return $res / 2;
    }

    /**
     * @throws Exception
     */
    private function updateRatingsForRace(object $race, mysqli $mysqli)
    {
        $raceId = $race->race_id;
        // Rating
        if ($raceId) {
            $q = "SELECT * FROM `tbl_hist_results` WHERE `rating`='0' AND `race_id`='$raceId'";
        } else {
            throw new Exception("No race ID found!");
        }

        $results = $mysqli->query($q);
        if ($results->num_rows > 0) {
            while ($row = $results->fetch_object()) {
                $logMessage = 'avgsectional: ' . $row->avgsectional . PHP_EOL;
                $logMessage .= 'rank: ' . $row->rank . PHP_EOL;
                $logMessage .= 'hist_id: ' . $row->hist_id;

                if ($row->avgsectional != "0" || $row->rank != "0") {
                    $ratePos = $row->avgsectional + $row->rank;
                    // modify by Jfrost
                    $ratePos = $ratePos + $this->getH2HPoint($row->horse_h2h);
                    $q = "UPDATE `tbl_hist_results` 
                                 SET `rating` = '$ratePos' , `temp_h2h` = " . $row->horse_h2h . "
                                 WHERE `hist_id` = '$row->hist_id';";
                    $mysqli->query($q);
                }
            }
        }
    }

    /**
     * @param $h2h
     * @return string
     */
    public function getH2HPoint($h2h): string
    {
        $h2hpoint = null;

        if (isset(explode("-", $h2h)[1])) {
            $h2h_ = intval(explode("-", $h2h)[0]) - intval(explode("-", $h2h)[1]);
        } else {
            $h2h_ = 0;
        }

        return number_format($h2h_ / 2, 1);
    }
}