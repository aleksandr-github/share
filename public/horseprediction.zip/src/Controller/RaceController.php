<?php

namespace App\Controller;

use App\Service\DBConnector;
use App\Service\PrettyLogger;
use Exception;
use mysqli;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;

class RaceController extends AbstractController
{
    protected $logger;

    protected $dbConnector;

    protected $session;

    /**
     * @throws Exception
     */
    public function __construct(SessionInterface $session)
    {
        $this->logger = new PrettyLogger(__FILE__, "race_details.txt");
        $this->logger->setLevel('DEBUG');
        $this->dbConnector = new DBConnector();
        $this->session = $session;
    }

    /**
     * @Route("/races/meeting/{meeting}/race/{race}", name="races_details")
     *
     * @param Request $request
     * @param $meeting
     * @param $race
     * @return Response
     */
    public function showOne(Request $request, $meeting, $race): Response
    {
        $mysqli = $this->dbConnector->getDbConnection();
        $raceDetails = $this->dbConnector->race_details($race);
        $meetingDetails = $this->dbConnector->meeting_details($meeting);
        $races = $mysqli->query("SELECT * FROM `tbl_races` WHERE `meeting_id`=" . $meetingDetails->meeting_id . " ORDER by race_order ASC");

        $resultsForRaceArray = $this->getResultsForRace($race);
        $resultsCombinedArray = [];

        $this->session->set('meeting_id', $meeting);
        $this->session->set('meeting_name', $meetingDetails->meeting_name);

        // TODO DO REFACTOR IMMEDIATELY
        $sqlfavg = "SELECT *, AVG(`rating`) rat, AVG(`rank`) avgrank FROM `tbl_hist_results` WHERE `race_id`='" . $race . "' GROUP BY `horse_id`";
        $max_1 = $max_2 = 0;
        $geting = $mysqli->query($sqlfavg);
        $ratin = array();
        while ($gnow = $geting->fetch_object()) {
            $ratin[] = number_format($gnow->rat, 2);
        }
        if (count($ratin) > '0') {
            $ismaxrat = max($ratin);

            $max_1 = $max_2 = -1;
            $maxused = 0;

            for ($i = 0; $i < count($ratin); $i++) {
                if ($ratin[$i] > $max_1) {
                    $max_2 = $max_1;
                    $max_1 = $ratin[$i];
                } else if ($ratin[$i] > $max_2) {
                    $max_2 = $ratin[$i];
                }
            }
        }

        $this->logger->log("Maxing distributes: " . $max_1 . " == " . $max_2 . "<br>");

        $getrnum = $mysqli->query("SELECT * FROM `tbl_temp_hraces` WHERE `race_id`='$race'");
        $temp = [];
        while ($ghorse = $getrnum->fetch_object()) {
            $sqlfavg = "SELECT *, AVG(`rating`) as rat, AVG(`rank`) as avgrank FROM `tbl_hist_results` WHERE `race_id`='" . $race . "' AND `horse_id`='$ghorse->horse_id' GROUP BY `horse_id`";
            $sqlavg = $mysqli->query($sqlfavg);

            while ($resavg = $sqlavg->fetch_assoc()) {
                $temp[] = $resavg;
            }

        }

        $getrnum = $mysqli->query("SELECT * FROM `tbl_temp_hraces` WHERE `race_id`='$race'");

        usort($temp, function($a, $b) {
            return ($a["avgrank"] <= $b["avgrank"]) ? -1 : 1;
        });

        $temp = array_reverse($temp);
        $table = array_slice($temp, 0, 2);
        $top_ids = [];
        foreach ($table as $arr) {
            $top_ids[] = $arr['horse_id'];
        }
        while ($ghorse = $getrnum->fetch_object()) {
            $horsedet = $this->dbConnector->horse_details($ghorse->horse_id);
            // This if condition shows from the homepage, without entering average or showing all

            // IF averages is not set
            if ($request->query->get('avg') != 1) {
                $resultsCombinedArray = $this->generateTableRowsForHistoricResults($race, $ghorse, $horsedet, $resultsCombinedArray);
            // IF AVERAGES IS SET!!!! (avg=1)
            } else {
                $resultsCombinedArray = $this->generateTableRowsForHistoricResultsAVG($race, $ghorse, $max_1, $max_2, $horsedet, $top_ids, $resultsCombinedArray);
            }
        }
        // TODO END REFACTOR

        return $this->render('race.html.twig', [
            'raceId' => $race,
            'meetingId' => $meeting,
            'raceDetails' => $raceDetails,
            'meetingDetails' => $meetingDetails,
            'races' => $races,
            'resultsForRace' => $resultsForRaceArray, // @TODO REFACTOR,
            'resultsCombinedArray' => $resultsCombinedArray // @TODO REFACTOR
        ]);
    }

    /**
     * @Route("/races/meeting/{meeting}", name="races_index")
     *
     * @param Request $request
     * @param $meeting
     * @return Response
     */
    public function showAll(Request $request, $meeting): Response
    {
        $this->logger->log('[MAIN] -> start');
        $this->logger->log('=== ');
        $mysqli = $this->dbConnector->getDbConnection();

        if ($mysqli->connect_error) {
            die("Connection failed: " . $mysqli->connect_error);
        }

        if(empty($meeting)) {
            echo "You must select a meeting";
            exit();
        }
        else {
            $meetingDetails = $this->dbConnector->meeting_details($meeting);
            $this->session->set('meeting_name', $meetingDetails->meeting_name);
            $this->session->set('meeting_id', $meetingDetails->meeting_id);
            $races = $mysqli->query("SELECT * FROM `tbl_races` WHERE `meeting_id`=" . $meetingDetails->meeting_id . " ORDER by race_order ASC");
        }
        
        return $this->render('races.html.twig', [
            'races' => $races,
            'meetingDetails' => $meetingDetails,
            'meetingId' => $meeting
        ]);
    }

    /**
     * @param $race
     * @return array
     */
    protected function getResultsForRace($race): array
    {
        $mysqli = $this->dbConnector->getDbConnection();
        $resultsForRaceArray = [];
        $resultsForRace = $mysqli->query("SELECT * FROM `tbl_results` WHERE `race_id`='" . $race . "' ORDER BY position ASC");
        if ($resultsForRace->num_rows > 0) {
            // output data of each row
            while ($raceResults = $resultsForRace->fetch_object()) {
                $horsedet = $this->dbConnector->horse_details($raceResults->horse_id);
                $racedet = $this->dbConnector->race_details($raceResults->race_id);
                $meetdet = $this->dbConnector->meeting_details($racedet->meeting_id);

                $resultsForRaceArray[] = [
                    'raceResultPosition' => $raceResults->position,
                    'horseName' => $horsedet->horse_name,
                    'roundDistance' => $racedet->round_distance,
                    'meetingName' => $meetdet->meeting_name,
                    'raceId' => $race,
                    'raceName' => $racedet->race_title
                ];
            }
        }

        return $resultsForRaceArray;
    }

    /**
     * @param mysqli $mysqli
     * @param $race
     * @param $ghorse
     * @param $horsedet
     * @param array $resultsCombinedArray
     * @return array
     */
    protected function generateTableRowsForHistoricResults($race, $ghorse, $horsedet, array $resultsCombinedArray): array
    {
        $mysqli = $this->dbConnector->getDbConnection();
        $sqlnow = $mysqli->query("SELECT *  FROM `tbl_hist_results` WHERE `race_id`='" . $race . "' AND `horse_id`='$ghorse->horse_id'");
        if ($sqlnow->num_rows > 0) {
            while ($resnow = $sqlnow->fetch_object()) {
                $resultsCombinedArray[] = [
                    'horseNum' => $ghorse->horse_num,
                    'horseName' => $horsedet->horse_name,
                    'horseLatestResults' => $horsedet->horse_latest_results,
                    'horseFxOdds' => $resnow->horse_fixed_odds,
                    'raceDistance' => $resnow->race_distance,
                    'raceSectional' => $resnow->sectional,
                    'raceTime' => $resnow->race_time,
                    'raceHorsePosition' => $resnow->horse_position,
                    'raceWeight' => $resnow->horse_weight,
                    'horseWeight' => $ghorse->horse_weight,
                    'handicap' => number_format($resnow->handicap, 3),
                    'rating' => $resnow->rating,
                    'rank' => $resnow->rank
                ];
            }
        } else {
            $resultsCombinedArray[] = [
                'horseNum' => $ghorse->horse_num,
                'horseName' => $horsedet->horse_name,
                'horseLatestResults' => $horsedet->horse_latest_results,
                'horseFxOdds' => $ghorse->horse_fxodds,
                'raceDistance' => null,
                'raceSectional' => null,
                'raceTime' => null,
                'raceHorsePosition' => null,
                'raceWeight' => null,
                'horseWeight' => null,
                'handicap' => null,
                'rating' => null,
                'rank' => null
            ];
        }
        return $resultsCombinedArray;
    }

    /**
     * @param $race
     * @param $ghorse
     * @param $max_1
     * @param $max_2
     * @param $horsedet
     * @param array $top_ids
     * @param array $resultsCombinedArray
     * @return array
     */
    protected function generateTableRowsForHistoricResultsAVG($race, $ghorse, $max_1, $max_2, $horsedet, array $top_ids, array $resultsCombinedArray): array
    {
        $mysqli = $this->dbConnector->getDbConnection();
        $sqlfavg = "SELECT *, AVG(`rating`) as rat, AVG(`rank`) as avgrank FROM `tbl_hist_results` WHERE `race_id`='" . $race . "' AND `horse_id`='$ghorse->horse_id' GROUP BY `horse_id`";
        // $sqlfavg = "SELECT *, AVG(rating) rat,AVG(rank) as avgrank FROM `tbl_hist_results` WHERE `race_id`='".$race_id."' GROUP BY horse_id";

        $geting = $mysqli->query($sqlfavg);
        $ratin = [];
        while ($gnow = $geting->fetch_object()) {
            $ratin[] = number_format($gnow->rat, 2);
        }
        /*
        if(count($ratin) > '0') {
        $ismaxrat = max($ratin);

        $max_1 = $max_2 = -1;
        $maxused = 0;

        for($i=0; $i<count($ratin); $i++) {
        if($ratin[$i] > $max_1) {
        $max_2 = $max_1;
        $max_1 = $ratin[$i];
        } else if($ratin[$i] > $max_2) {
        $max_2 = $ratin[$i];
        }
        }
        }
        */

        //here from
        $cnt = 1;
        $ratenow = array();

        $sqlavg = $mysqli->query($sqlfavg);
        if ($sqlavg->num_rows > 0) {
            while ($resavg = $sqlavg->fetch_object()) {
                $rating = number_format($resavg->rat, 2);
                $ratenow[] = $rating;
                $avgrank = number_format($resavg->avgrank, 2);
                $odds = str_replace("$", "", $resavg->horse_fixed_odds);

                $posres = $mysqli->query("SELECT position FROM `tbl_results` WHERE `race_id`='" . $race . "' AND `horse_id`='$ghorse->horse_id' LIMIT 1");
                while ($prow = $posres->fetch_object()) {
                    $position = $prow->position;
                }

                if ($cnt < 3) {
                    //$position = $resavg->horse_position;
                    if (!empty($position)) {
                        if ($position < 2) {
                            $profit = 10 * floatval($odds) - 10;
                        } else {
                            $profit = -10;
                        }
                    } else {
                        $profit = "";
                    }
                } else {
                    $profit = "";
                }

                $profitloss = "";
                //$position = $resavg->horse_position;

                if (!empty($position)) {
                    if ($rating && $position > 2) {
                        if ($rating > 0) {
                            if ($rating == $max_1 || $rating == $max_2) {
                                $profitloss = 10 * 0 - 10;
                            } else {
                                $profitloss = "";
                            }
                        }
                    } else {
                        if ($rating > 0) {
                            if ($rating == $max_1 || $rating == $max_2) {
                                //  $pos =  explode('/', $resavg->horse_position);
                                //  $position =  intval($pos[0]);

                                if ($position != 1) {
                                    $profitloss = 10 * 0 - 10;
                                } else {
                                    $profitloss = 10 * $odds - 10;
                                }
                            } else {
                                $profitloss = "";
                            }
                        }
                    }
                } else {
                    $profitloss = "";
                }

                $resultsCombinedArray[] = [
                    'horseNum' => $ghorse->horse_num,
                    'horseName' => $horsedet->horse_name,
                    'horseLatestResults' => $horsedet->horse_latest_results,
                    'horseFxOdds' => $resavg->horse_fixed_odds,
                    'raceDistance' => null,
                    'raceSectional' => null,
                    'raceTime' => null,
                    'raceHorsePosition' => null,
                    'raceWeight' => $resavg->horse_weight,
                    'horseWeight' => $resavg->horse_weight,
                    'rating' => $rating,
                    'profitLoss' => $profitloss,
                    'rank' => $avgrank,
                    'profit' => ((!in_array($horsedet->horse_id, $top_ids)) ? null : $profit)
                ];
                ++$cnt;
            }
        } else {
            $resultsCombinedArray[] = [
                'horseNum' => $ghorse->horse_num,
                'horseName' => $horsedet->horse_name,
                'horseLatestResults' => $horsedet->horse_latest_results,
                'horseFxOdds' => $ghorse->horse_fxodds,
                'raceDistance' => null,
                'raceSectional' => null,
                'raceTime' => null,
                'raceHorsePosition' => null,
                'raceWeight' => null,
                'horseWeight' => null,
                'rating' => null,
                'profitLoss' => null,
                'rank' => null,
                'profit' => null
            ];
        }
        return $resultsCombinedArray;
    }
}