<?php

namespace App\Controller;

use App\Service\DBConnector;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    /**
     * @var DBConnector
     */
    protected $dbConnector;

    /**
     * @var \mysqli
     */
    protected $mysqli;

    public function __construct(DBConnector $dbConnector)
    {
        $this->dbConnector = $dbConnector;
        $this->mysqli = $dbConnector->getDbConnection();
    }

    /**
     * @Route("/", name="index")
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function show(Request $request): Response
    {
        $data_data = array();
        $horse_data = array();

        $sql = "SELECT horse_name,hr.horse_id,hr.race_id,hr.horse_position, AVG(rating) AS rating, (SUM(hr.rank)/COUNT(hr.race_id)) AS ranks, horse_fixed_odds 
FROM tbl_hist_results hr INNER JOIN tbl_horses h ON hr.horse_id = h.horse_id WHERE 1 GROUP BY hr.horse_id ";
        $result = $this->mysqli->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data_data[$row['horse_name']] = array(
                    'rating' => $row['rating'],
                    'rank' => $row['ranks'],
                    'horse_fixed_odds' => $row['horse_fixed_odds']
                );
                $horse_data[] = array(
                    $row['race_id'],
                    $row['horse_name'],
                    $row['rating'],
                    $row['ranks'],
                    $row['horse_position'],
                    $row['horse_fixed_odds'],
                    // modify by JFrost
                    $row['horse_id'],
                );
            }
        }

        $totalProfitAVR = 0;
        $totalLossAVR = 0;

        $sql_raceid = "SELECT race_id  FROM tbl_races";
        $result_raceid = $this->mysqli->query($sql_raceid);


        $realResultsAVGArray = [];
        if ($result_raceid->num_rows > 0) {

            // output data of each row
            while ($row_id = $result_raceid->fetch_assoc()) {

                $temp_array = array();
                $race_data = array_column($horse_data, 0);

                foreach ($race_data as $k => $r) {
                    if ($row_id['race_id'] == $r) {
                        $temp_array[] = $horse_data[$k];
                    }
                }

                usort($temp_array, function ($a, $b) {
                    // if ($a[2] == $b[2])
                    //     return 0;
                    // return ($a[2] < $b[2]) ? -1 : 1;
                    return strcmp($a[2], $b[2]) * -1;
                });

                if (count($temp_array) > 0) {
                    if ($request->query->get('mode') == 2) {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1]
                        );
                    } elseif ($request->query->get('mode') == 3) {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1],
                            $temp_array[2]
                        );
                    } else {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1]
                        );
                    }
                    $ratin = array();

                    if (count($real_result) > 0) {
                        foreach ($real_result as $row) {
                            $ratin[] = number_format(floatval($row[2]), 0);
                            $avgrank = number_format(floatval($row[3]), 2);
                            $odds = str_replace("$", "", $row[5]);
                            $position = intval($row[4]);
                            $profit = $row[4] == "" ? 0 : (($position == 1) ? ((10 * floatval($odds)) - 10) : -10);
                            $totalLossAVR += ($profit < 0) ? 10 : 0;
                            $totalProfitAVR += $profit;

                            $realResultsAVGArray[] = json_decode(json_encode([
                                'raceId' => $row_id['race_id'],
                                'horseId' => $row[6],
                                'horse' => $row[1],
                                'revenue' => $profit,
                                'total' => $totalProfitAVR
                            ]));
                        }
                    }
                }
            }
        }

        // TOTAL RANK PROFIT CALCULATION
        $data_data = array();
        $data_id = array();
        $sql = "SELECT horse_name, AVG(rating) as rating, (SUM(hr.rank)/COUNT(hr.race_id)) AS ranks, horse_fixed_odds FROM tbl_hist_results hr INNER JOIN tbl_horses h ON hr.horse_id = h.horse_id WHERE 1 GROUP BY horse_name";
        $result = $this->mysqli->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data_data[$row['horse_name']] = array(
                    'rating' => $row['rating'],
                    'rank' => $row['ranks'],
                    'horse_fixed_odds' => $row['horse_fixed_odds']
                );
            }
        }

        $results_data = array();
        $results_id = array();
        $sql = "select * from `tbl_results`";
        $result = $this->mysqli->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $results_data[$row['horse_id']] = array('race_id' => $row['race_id'], 'position' => $row['position']);
            }
        }

        $horse_data = array();
        $sql = "SELECT * FROM `tbl_horses` ORDER BY horse_id ASC";
        $result = $this->mysqli->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                $rating = '';
                $rank = '';
                $odds = '';

                if (isset($data_data[$row['horse_name']])) {
                    $rating = $data_data[$row['horse_name']]["rating"];
                    $rank = $data_data[$row['horse_name']]["rank"];
                    $odds = $data_data[$row['horse_name']]['horse_fixed_odds'];
                }

                $position = '';
                $race_id = '';
                if (isset($results_data[$row['horse_id']])) {
                    $race_id = $results_data[$row['horse_id']]['race_id'];
                    $position = $results_data[$row['horse_id']]['position'];
                }

                $horse_data[] = array(
                    $race_id,
                    $row['horse_name'],
                    $rating,
                    $rank,
                    $position,
                    $odds,
                    // modify by JFrost
                    $row['horse_id'],
                );
            }
        }

        $total_profit = 0;
        $total_loss = 0;

        $sql_raceid = "SELECT race_id  FROM tbl_races";
        $result_raceid = $this->mysqli->query($sql_raceid);

        echo "";


        $realResultsArray = [];
        if ($result_raceid->num_rows > 0) {

            // output data of each row
            while ($row_id = $result_raceid->fetch_assoc()) {

                $temp_array = array();
                $race_data = array_column($horse_data, 0);

                foreach ($race_data as $k => $r) {
                    if ($row_id['race_id'] == $r) {
                        $temp_array[] = $horse_data[$k];
                    }
                }
                usort($temp_array, function ($a, $b) {
                    if ($a[2] === $b[2])
                        return 0;
                    return ($a[2] > $b[2]) ? -1 : 1;
                });

                if (count($temp_array) > 0) {
                    if ($request->query->get('mode') == 2) {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1]
                        );
                    } elseif ($request->query->get('mode') == 3) {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1],
                            $temp_array[2]
                        );
                    } else {
                        $real_result = array(
                            $temp_array[0],
                            $temp_array[1]
                        );
                    }
                    $ratin = array();

                    if (count($real_result) > 0) {
                        foreach ($real_result as $row) {
                            $ratin[] = number_format(floatval($row[2]), 0);
                            $odds = str_replace("$", "", $row[5]);
                            $position = intval($row[4]);
                            $profit = $row[4] == "" ? 0 : (($position == 1) ? ((10 * $odds) - 10) : -10);
                            $total_loss += ($profit < 0) ? 10 : 0;
                            $total_profit += $profit;
                            // modify by Jfrost
                            $realResultsArray[] = json_decode(json_encode([
                                'horseId' => $row[6],
                                'raceId' => $row_id['race_id'],
                                'horse' => $row[1],
                                'revenue' => $profit,
                                'total' => $total_profit
                            ]));
                        }
                    }
                }
            }
        }

        return $this->render('home.html.twig', [
            'totalProfit' => $total_profit,
            'totalLoss' => $total_loss,
            'realResultsArray' => $realResultsArray,
            'totalProfitAVR' => $totalProfitAVR,
            'totalLossAVR' => $totalLossAVR,
            'realResultsAVGArray' => $realResultsAVGArray,
            'requestMode' => $request->query->get('mode')
        ]);
    }
}